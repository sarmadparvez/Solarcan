<?php

$dictionary['Contact']['fields']['contacts_dsm_dnc_historic'] = array(
    'name' => 'contacts_dsm_dnc_historic',
    'type' => 'link',
    'relationship' => 'contacts_dsm_dnc_historic',
    'module' => 'dsm_dnc_historic',
    'bean_name' => 'dsm_dnc_historic',
    'source' => 'non-db',
    'vname' => 'LBL_DSM_DNC_HISTORIC',
);
