<?php
 // created: 2018-01-25 16:57:23
$dictionary['Contact']['fields']['date_de_consentement_datestamp']['name']='date_de_consentement_datestamp';
$dictionary['Contact']['fields']['date_de_consentement_datestamp']['vname']='LBL_DATE_DE_CONSENTEMENT_DATESTAMP';
$dictionary['Contact']['fields']['date_de_consentement_datestamp']['type']='datetime';
$dictionary['Contact']['fields']['date_de_consentement_datestamp']['massupdate']=true;
$dictionary['Contact']['fields']['date_de_consentement_datestamp']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['date_de_consentement_datestamp']['merge_filter']='enabled';
$dictionary['Contact']['fields']['date_de_consentement_datestamp']['calculated']=false;
$dictionary['Contact']['fields']['date_de_consentement_datestamp']['required']=false;
$dictionary['Contact']['fields']['date_de_consentement_datestamp']['audited']=true;
$dictionary['Contact']['fields']['date_de_consentement_datestamp']['importable']='true';
$dictionary['Contact']['fields']['date_de_consentement_datestamp']['duplicate_merge_dom_value']='2';
$dictionary['Contact']['fields']['date_de_consentement_datestamp']['enable_range_search']=false;

 ?>