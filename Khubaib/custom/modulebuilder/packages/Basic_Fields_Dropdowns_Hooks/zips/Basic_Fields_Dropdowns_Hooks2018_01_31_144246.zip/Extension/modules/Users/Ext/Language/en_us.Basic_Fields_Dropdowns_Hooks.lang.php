<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_PREFERRED_LANGUAGE'] = 'Language Preference:';
$mod_strings['LBL_CAN_SELL'] = 'Can sell';
