<?php
 // created: 2018-01-23 15:38:33
$dictionary['Call']['fields']['repeat_dow']['name']='repeat_dow';
$dictionary['Call']['fields']['repeat_dow']['vname']='LBL_REPEAT_DOW';
$dictionary['Call']['fields']['repeat_dow']['type']='varchar';
$dictionary['Call']['fields']['repeat_dow']['dbType']='varchar';
$dictionary['Call']['fields']['repeat_dow']['massupdate']=false;
$dictionary['Call']['fields']['repeat_dow']['duplicate_merge']='enabled';
$dictionary['Call']['fields']['repeat_dow']['merge_filter']='enabled';
$dictionary['Call']['fields']['repeat_dow']['calculated']=false;
$dictionary['Call']['fields']['repeat_dow']['required']=false;
$dictionary['Call']['fields']['repeat_dow']['audited']=true;
$dictionary['Call']['fields']['repeat_dow']['importable']='true';
$dictionary['Call']['fields']['repeat_dow']['duplicate_merge_dom_value']='2';
$dictionary['Call']['fields']['repeat_dow']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>