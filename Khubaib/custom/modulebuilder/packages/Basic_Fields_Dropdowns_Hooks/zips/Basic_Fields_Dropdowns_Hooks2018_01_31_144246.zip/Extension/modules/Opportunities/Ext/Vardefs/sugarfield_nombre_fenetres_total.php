<?php
 // created: 2018-01-25 12:03:18
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['name']='nombre_fenetres_total';
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['vname']='LBL_NOMBRE_FENETRES_TOTAL';
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['type']='varchar';
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['dbType']='varchar';
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['massupdate']=false;
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['duplicate_merge']='disabled';
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['calculated']='true';
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['required']=true;
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['audited']=true;
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['importable']='false';
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['formula']='related($accounts,"nombre_fenetres_total")';
$dictionary['Opportunity']['fields']['nombre_fenetres_total']['enforced']=true;

 ?>