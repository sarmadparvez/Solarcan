<?php
 // created: 2018-01-29 16:20:27
$dictionary['dsm_dnc_historic']['fields']['modified_by']['name']='modified_by';
$dictionary['dsm_dnc_historic']['fields']['modified_by']['vname']='LBL_MODIFIED_BY';
$dictionary['dsm_dnc_historic']['fields']['modified_by']['type']='enum';
$dictionary['dsm_dnc_historic']['fields']['modified_by']['options']='dnc_source_dom';
$dictionary['dsm_dnc_historic']['fields']['modified_by']['massupdate']=false;
$dictionary['dsm_dnc_historic']['fields']['modified_by']['duplicate_merge']='enabled';
$dictionary['dsm_dnc_historic']['fields']['modified_by']['merge_filter']='enabled';
$dictionary['dsm_dnc_historic']['fields']['modified_by']['calculated']=false;
$dictionary['dsm_dnc_historic']['fields']['modified_by']['required']=false;
$dictionary['dsm_dnc_historic']['fields']['modified_by']['audited']=false;
$dictionary['dsm_dnc_historic']['fields']['modified_by']['studio']='visible';
$dictionary['dsm_dnc_historic']['fields']['modified_by']['importable']='true';
$dictionary['dsm_dnc_historic']['fields']['modified_by']['duplicate_merge_dom_value']='2';
$dictionary['dsm_dnc_historic']['fields']['modified_by']['unified_search']=false;
$dictionary['dsm_dnc_historic']['fields']['modified_by']['dependency']=false;

 ?>