<?php
 // created: 2018-01-24 12:47:29
$dictionary['Contact']['fields']['occupant_depuis']['name']='occupant_depuis';
$dictionary['Contact']['fields']['occupant_depuis']['vname']='LBL_OCCUPANT_DEPUIS';
$dictionary['Contact']['fields']['occupant_depuis']['type']='varchar';
$dictionary['Contact']['fields']['occupant_depuis']['dbType']='varchar';
$dictionary['Contact']['fields']['occupant_depuis']['massupdate']=false;
$dictionary['Contact']['fields']['occupant_depuis']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['occupant_depuis']['merge_filter']='enabled';
$dictionary['Contact']['fields']['occupant_depuis']['calculated']=false;
$dictionary['Contact']['fields']['occupant_depuis']['required']=true;
$dictionary['Contact']['fields']['occupant_depuis']['audited']=true;
$dictionary['Contact']['fields']['occupant_depuis']['importable']='true';
$dictionary['Contact']['fields']['occupant_depuis']['duplicate_merge_dom_value']='2';
$dictionary['Contact']['fields']['occupant_depuis']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>