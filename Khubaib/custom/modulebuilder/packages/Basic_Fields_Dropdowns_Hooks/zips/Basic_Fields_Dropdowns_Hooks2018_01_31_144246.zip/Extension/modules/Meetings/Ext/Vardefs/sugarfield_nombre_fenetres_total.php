<?php
 // created: 2018-01-25 12:39:15
$dictionary['Meeting']['fields']['nombre_fenetres_total']['name']='nombre_fenetres_total';
$dictionary['Meeting']['fields']['nombre_fenetres_total']['vname']='LBL_NOMBRE_FENETRES_TOTAL';
$dictionary['Meeting']['fields']['nombre_fenetres_total']['type']='varchar';
$dictionary['Meeting']['fields']['nombre_fenetres_total']['dbType']='varchar';
$dictionary['Meeting']['fields']['nombre_fenetres_total']['massupdate']=false;
$dictionary['Meeting']['fields']['nombre_fenetres_total']['duplicate_merge']='disabled';
$dictionary['Meeting']['fields']['nombre_fenetres_total']['merge_filter']='disabled';
$dictionary['Meeting']['fields']['nombre_fenetres_total']['calculated']='1';
$dictionary['Meeting']['fields']['nombre_fenetres_total']['required']=false;
$dictionary['Meeting']['fields']['nombre_fenetres_total']['audited']=true;
$dictionary['Meeting']['fields']['nombre_fenetres_total']['importable']='false';
$dictionary['Meeting']['fields']['nombre_fenetres_total']['duplicate_merge_dom_value']=0;
$dictionary['Meeting']['fields']['nombre_fenetres_total']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Meeting']['fields']['nombre_fenetres_total']['formula']='related($accounts,"nombre_fenetres_total")';
$dictionary['Meeting']['fields']['nombre_fenetres_total']['enforced']=true;

 ?>