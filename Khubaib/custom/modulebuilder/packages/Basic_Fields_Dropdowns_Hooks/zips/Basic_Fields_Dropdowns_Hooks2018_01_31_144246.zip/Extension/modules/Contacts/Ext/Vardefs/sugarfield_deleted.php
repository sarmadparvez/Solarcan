<?php
 // created: 2018-01-23 15:27:53
$dictionary['Contact']['fields']['deleted']['default']=false;
$dictionary['Contact']['fields']['deleted']['audited']=false;
$dictionary['Contact']['fields']['deleted']['massupdate']=false;
$dictionary['Contact']['fields']['deleted']['comments']='Record deletion indicator';
$dictionary['Contact']['fields']['deleted']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['deleted']['duplicate_merge_dom_value']=1;
$dictionary['Contact']['fields']['deleted']['merge_filter']='disabled';
$dictionary['Contact']['fields']['deleted']['reportable']=true;
$dictionary['Contact']['fields']['deleted']['unified_search']=false;
$dictionary['Contact']['fields']['deleted']['calculated']=false;

 ?>