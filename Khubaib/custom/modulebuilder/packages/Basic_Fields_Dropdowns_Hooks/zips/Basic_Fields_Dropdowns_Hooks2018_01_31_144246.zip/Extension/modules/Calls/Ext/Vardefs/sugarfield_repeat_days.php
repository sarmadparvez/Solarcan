<?php
 // created: 2018-01-23 19:11:16
$dictionary['Call']['fields']['repeat_days']['name']='repeat_days';
$dictionary['Call']['fields']['repeat_days']['vname']='LBL_REPEAT_DAYS';
$dictionary['Call']['fields']['repeat_days']['type']='varchar';
$dictionary['Call']['fields']['repeat_days']['dbType']='varchar';
$dictionary['Call']['fields']['repeat_days']['massupdate']=false;
$dictionary['Call']['fields']['repeat_days']['duplicate_merge']='enabled';
$dictionary['Call']['fields']['repeat_days']['merge_filter']='enabled';
$dictionary['Call']['fields']['repeat_days']['calculated']=false;
$dictionary['Call']['fields']['repeat_days']['required']=false;
$dictionary['Call']['fields']['repeat_days']['audited']=true;
$dictionary['Call']['fields']['repeat_days']['importable']='true';
$dictionary['Call']['fields']['repeat_days']['duplicate_merge_dom_value']='2';
$dictionary['Call']['fields']['repeat_days']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>