<?php
 // created: 2018-01-23 15:35:50
$dictionary['Contact']['fields']['mkto_id']['audited']=false;
$dictionary['Contact']['fields']['mkto_id']['massupdate']=false;
$dictionary['Contact']['fields']['mkto_id']['comments']='Associated Marketo Lead ID';
$dictionary['Contact']['fields']['mkto_id']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['mkto_id']['duplicate_merge_dom_value']='1';
$dictionary['Contact']['fields']['mkto_id']['merge_filter']='disabled';
$dictionary['Contact']['fields']['mkto_id']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Contact']['fields']['mkto_id']['calculated']=false;
$dictionary['Contact']['fields']['mkto_id']['enable_range_search']=false;
$dictionary['Contact']['fields']['mkto_id']['min']=false;
$dictionary['Contact']['fields']['mkto_id']['max']=false;
$dictionary['Contact']['fields']['mkto_id']['disable_num_format']='';

 ?>