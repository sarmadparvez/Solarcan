<?php
 // created: 2018-01-29 15:19:58
$dictionary['Contact']['fields']['statut_dnc']['name']='statut_dnc';
$dictionary['Contact']['fields']['statut_dnc']['vname']='LBL_STATUT_DNC';
$dictionary['Contact']['fields']['statut_dnc']['type']='text';
$dictionary['Contact']['fields']['statut_dnc']['dbType']='varchar';
$dictionary['Contact']['fields']['statut_dnc']['massupdate']=false;
$dictionary['Contact']['fields']['statut_dnc']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['statut_dnc']['merge_filter']='enabled';
$dictionary['Contact']['fields']['statut_dnc']['calculated']=false;
$dictionary['Contact']['fields']['statut_dnc']['required']=false;
$dictionary['Contact']['fields']['statut_dnc']['default']='Active';
$dictionary['Contact']['fields']['statut_dnc']['audited']=true;
$dictionary['Contact']['fields']['statut_dnc']['importable']='true';
$dictionary['Contact']['fields']['statut_dnc']['duplicate_merge_dom_value']='2';
$dictionary['Contact']['fields']['statut_dnc']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Contact']['fields']['statut_dnc']['rows']='4';
$dictionary['Contact']['fields']['statut_dnc']['cols']='20';

 ?>