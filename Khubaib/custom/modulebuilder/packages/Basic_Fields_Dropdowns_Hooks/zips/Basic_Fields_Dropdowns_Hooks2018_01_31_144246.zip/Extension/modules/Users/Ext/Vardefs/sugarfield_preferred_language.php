<?php
 // created: 2018-01-30 17:39:59
$dictionary['User']['fields']['preferred_language']['default']='en_us';
$dictionary['User']['fields']['preferred_language']['required']=false;
$dictionary['User']['fields']['preferred_language']['audited']=false;
$dictionary['User']['fields']['preferred_language']['massupdate']=true;
$dictionary['User']['fields']['preferred_language']['duplicate_merge']='enabled';
$dictionary['User']['fields']['preferred_language']['duplicate_merge_dom_value']='1';
$dictionary['User']['fields']['preferred_language']['merge_filter']='disabled';
$dictionary['User']['fields']['preferred_language']['unified_search']=false;
$dictionary['User']['fields']['preferred_language']['calculated']=false;
$dictionary['User']['fields']['preferred_language']['dependency']=false;

 ?>