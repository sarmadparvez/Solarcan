<?php
 // created: 2018-01-24 12:46:23
$dictionary['Contact']['fields']['phone_home']['len']='100';
$dictionary['Contact']['fields']['phone_home']['audited']=false;
$dictionary['Contact']['fields']['phone_home']['massupdate']=false;
$dictionary['Contact']['fields']['phone_home']['comments']='Home phone number of the contact';
$dictionary['Contact']['fields']['phone_home']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['phone_home']['duplicate_merge_dom_value']='1';
$dictionary['Contact']['fields']['phone_home']['merge_filter']='disabled';
$dictionary['Contact']['fields']['phone_home']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.1',
  'searchable' => true,
);
$dictionary['Contact']['fields']['phone_home']['calculated']=false;
$dictionary['Contact']['fields']['phone_home']['required']=true;

 ?>