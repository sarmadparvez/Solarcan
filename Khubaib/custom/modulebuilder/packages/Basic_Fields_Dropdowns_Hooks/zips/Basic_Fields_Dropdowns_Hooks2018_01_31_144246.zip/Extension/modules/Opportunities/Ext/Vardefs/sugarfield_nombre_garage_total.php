<?php
 // created: 2018-01-25 12:04:39
$dictionary['Opportunity']['fields']['nombre_garage_total']['name']='nombre_garage_total';
$dictionary['Opportunity']['fields']['nombre_garage_total']['vname']='LBL_NOMBRE_GARAGE_TOTAL';
$dictionary['Opportunity']['fields']['nombre_garage_total']['type']='varchar';
$dictionary['Opportunity']['fields']['nombre_garage_total']['dbType']='varchar';
$dictionary['Opportunity']['fields']['nombre_garage_total']['massupdate']=false;
$dictionary['Opportunity']['fields']['nombre_garage_total']['duplicate_merge']='disabled';
$dictionary['Opportunity']['fields']['nombre_garage_total']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['nombre_garage_total']['calculated']='true';
$dictionary['Opportunity']['fields']['nombre_garage_total']['required']=true;
$dictionary['Opportunity']['fields']['nombre_garage_total']['audited']=true;
$dictionary['Opportunity']['fields']['nombre_garage_total']['importable']='false';
$dictionary['Opportunity']['fields']['nombre_garage_total']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['nombre_garage_total']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['nombre_garage_total']['formula']='related($accounts,"nombre_garage_total")';
$dictionary['Opportunity']['fields']['nombre_garage_total']['enforced']=true;

 ?>