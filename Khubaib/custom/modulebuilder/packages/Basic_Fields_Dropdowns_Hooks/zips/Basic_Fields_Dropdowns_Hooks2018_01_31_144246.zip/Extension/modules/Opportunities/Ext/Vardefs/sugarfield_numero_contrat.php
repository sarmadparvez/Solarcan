<?php
 // created: 2018-01-23 16:18:00
$dictionary['Opportunity']['fields']['numero_contrat']['name']='numero_contrat';
$dictionary['Opportunity']['fields']['numero_contrat']['vname']='LBL_NUMERO_CONTRAT';
$dictionary['Opportunity']['fields']['numero_contrat']['type']='varchar';
$dictionary['Opportunity']['fields']['numero_contrat']['dbType']='varchar';
$dictionary['Opportunity']['fields']['numero_contrat']['massupdate']=false;
$dictionary['Opportunity']['fields']['numero_contrat']['duplicate_merge']='enabled';
$dictionary['Opportunity']['fields']['numero_contrat']['merge_filter']='enabled';
$dictionary['Opportunity']['fields']['numero_contrat']['calculated']=false;
$dictionary['Opportunity']['fields']['numero_contrat']['required']=false;
$dictionary['Opportunity']['fields']['numero_contrat']['audited']=true;
$dictionary['Opportunity']['fields']['numero_contrat']['importable']='true';
$dictionary['Opportunity']['fields']['numero_contrat']['duplicate_merge_dom_value']='2';
$dictionary['Opportunity']['fields']['numero_contrat']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>