<?php

$dictionary['Meeting']['fields']['duration_minutes'] = array(
    'name' => 'duration_minutes',
    'vname' => 'LBL_DURATION_MINUTES',
    'type' => 'int',
    'dbType' => 'int',
    'default' => NULL,
    'audited' => true,
    'mass_update' => false,
    'duplicate_merge' => true,
    'reportable' => true,
    'importable' => 'false',
);
