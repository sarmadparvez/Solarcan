<?php
 // created: 2018-01-25 16:57:40
$dictionary['Contact']['fields']['consentement']['name']='consentement';
$dictionary['Contact']['fields']['consentement']['vname']='LBL_CONSENTEMENT';
$dictionary['Contact']['fields']['consentement']['type']='bool';
$dictionary['Contact']['fields']['consentement']['massupdate']=false;
$dictionary['Contact']['fields']['consentement']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['consentement']['merge_filter']='enabled';
$dictionary['Contact']['fields']['consentement']['calculated']=false;
$dictionary['Contact']['fields']['consentement']['required']=false;
$dictionary['Contact']['fields']['consentement']['audited']=true;
$dictionary['Contact']['fields']['consentement']['importable']='true';
$dictionary['Contact']['fields']['consentement']['duplicate_merge_dom_value']='2';
$dictionary['Contact']['fields']['consentement']['default']=false;
$dictionary['Contact']['fields']['consentement']['reportable']=false;
$dictionary['Contact']['fields']['consentement']['unified_search']=false;

 ?>