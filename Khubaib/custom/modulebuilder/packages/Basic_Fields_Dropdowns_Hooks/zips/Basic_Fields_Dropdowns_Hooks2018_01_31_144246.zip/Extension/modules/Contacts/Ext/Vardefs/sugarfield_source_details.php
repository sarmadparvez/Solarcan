<?php
 // created: 2018-01-23 18:05:59
$dictionary['Contact']['fields']['source_details']['name']='source_details';
$dictionary['Contact']['fields']['source_details']['vname']='LBL_SOURCE_DETAILS';
$dictionary['Contact']['fields']['source_details']['type']='enum';
$dictionary['Contact']['fields']['source_details']['massupdate']=true;
$dictionary['Contact']['fields']['source_details']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['source_details']['merge_filter']='enabled';
$dictionary['Contact']['fields']['source_details']['calculated']=false;
$dictionary['Contact']['fields']['source_details']['required']=true;
$dictionary['Contact']['fields']['source_details']['len']=100;
$dictionary['Contact']['fields']['source_details']['audited']=true;
$dictionary['Contact']['fields']['source_details']['importable']='true';
$dictionary['Contact']['fields']['source_details']['options']='source_details_dom';
$dictionary['Contact']['fields']['source_details']['duplicate_merge_dom_value']='2';
$dictionary['Contact']['fields']['source_details']['dependency']=false;

 ?>