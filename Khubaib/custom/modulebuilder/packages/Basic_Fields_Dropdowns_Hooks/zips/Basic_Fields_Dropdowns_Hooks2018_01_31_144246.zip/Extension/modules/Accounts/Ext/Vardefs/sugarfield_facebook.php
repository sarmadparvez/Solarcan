<?php
 // created: 2018-01-23 15:41:30
$dictionary['Account']['fields']['facebook']['audited']=false;
$dictionary['Account']['fields']['facebook']['massupdate']=false;
$dictionary['Account']['fields']['facebook']['comments']='The facebook name of the company';
$dictionary['Account']['fields']['facebook']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['facebook']['duplicate_merge_dom_value']='1';
$dictionary['Account']['fields']['facebook']['merge_filter']='disabled';
$dictionary['Account']['fields']['facebook']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Account']['fields']['facebook']['calculated']=false;

 ?>