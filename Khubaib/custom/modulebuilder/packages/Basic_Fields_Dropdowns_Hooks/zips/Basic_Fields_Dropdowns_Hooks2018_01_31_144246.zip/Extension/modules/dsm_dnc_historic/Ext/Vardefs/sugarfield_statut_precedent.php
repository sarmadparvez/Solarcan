<?php
 // created: 2018-01-24 19:47:42
$dictionary['dsm_dnc_historic']['fields']['statut_precedent']['name']='statut_precedent';
$dictionary['dsm_dnc_historic']['fields']['statut_precedent']['vname']='LBL_STATUT_PRECEDENT';
$dictionary['dsm_dnc_historic']['fields']['statut_precedent']['type']='varchar';
$dictionary['dsm_dnc_historic']['fields']['statut_precedent']['dbType']='varchar';
$dictionary['dsm_dnc_historic']['fields']['statut_precedent']['massupdate']=false;
$dictionary['dsm_dnc_historic']['fields']['statut_precedent']['duplicate_merge']='enabled';
$dictionary['dsm_dnc_historic']['fields']['statut_precedent']['merge_filter']='enabled';
$dictionary['dsm_dnc_historic']['fields']['statut_precedent']['calculated']=false;
$dictionary['dsm_dnc_historic']['fields']['statut_precedent']['required']=true;
$dictionary['dsm_dnc_historic']['fields']['statut_precedent']['audited']=true;
$dictionary['dsm_dnc_historic']['fields']['statut_precedent']['importable']='true';
$dictionary['dsm_dnc_historic']['fields']['statut_precedent']['duplicate_merge_dom_value']='2';
$dictionary['dsm_dnc_historic']['fields']['statut_precedent']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['dsm_dnc_historic']['fields']['statut_precedent']['unified_search']=false;

 ?>