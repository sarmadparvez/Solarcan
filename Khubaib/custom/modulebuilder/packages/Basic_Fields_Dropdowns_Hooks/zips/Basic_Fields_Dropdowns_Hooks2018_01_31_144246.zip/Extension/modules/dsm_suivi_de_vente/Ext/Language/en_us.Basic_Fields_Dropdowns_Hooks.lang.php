<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_NUMERO_DE_CONTRAT'] = 'Numero de contrat';
$mod_strings['LBL_MONTANT'] = 'Montant';
$mod_strings['LBL_DEPOT'] = 'Depot';
$mod_strings['LBL_NUMERO_DE_CHEQUE'] = 'Numero de cheque';
