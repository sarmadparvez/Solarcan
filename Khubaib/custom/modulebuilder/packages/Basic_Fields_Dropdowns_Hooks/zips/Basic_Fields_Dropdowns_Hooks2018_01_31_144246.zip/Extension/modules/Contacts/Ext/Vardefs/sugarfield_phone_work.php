<?php
 // created: 2018-01-23 15:30:31
$dictionary['Contact']['fields']['phone_work']['len']='100';
$dictionary['Contact']['fields']['phone_work']['audited']=false;
$dictionary['Contact']['fields']['phone_work']['massupdate']=false;
$dictionary['Contact']['fields']['phone_work']['comments']='Work phone number of the contact';
$dictionary['Contact']['fields']['phone_work']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['phone_work']['duplicate_merge_dom_value']='1';
$dictionary['Contact']['fields']['phone_work']['merge_filter']='disabled';
$dictionary['Contact']['fields']['phone_work']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.08',
  'searchable' => true,
);
$dictionary['Contact']['fields']['phone_work']['calculated']=false;

 ?>