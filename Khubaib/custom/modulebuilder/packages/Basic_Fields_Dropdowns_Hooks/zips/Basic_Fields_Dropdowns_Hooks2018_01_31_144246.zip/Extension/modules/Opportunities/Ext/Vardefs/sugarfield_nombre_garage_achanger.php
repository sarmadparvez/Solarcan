<?php
 // created: 2018-01-25 12:04:17
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['name']='nombre_garage_achanger';
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['vname']='LBL_NOMBRE_GARAGE_ACHANGER';
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['type']='varchar';
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['dbType']='varchar';
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['massupdate']=false;
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['duplicate_merge']='disabled';
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['calculated']='true';
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['required']=true;
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['audited']=true;
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['importable']='false';
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['formula']='related($accounts,"nombre_garage_achanger")';
$dictionary['Opportunity']['fields']['nombre_garage_achanger']['enforced']=true;

 ?>