<?php
 // created: 2018-01-23 15:41:42
$dictionary['Account']['fields']['googleplus']['audited']=false;
$dictionary['Account']['fields']['googleplus']['massupdate']=false;
$dictionary['Account']['fields']['googleplus']['comments']='The Google Plus name of the company';
$dictionary['Account']['fields']['googleplus']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['googleplus']['duplicate_merge_dom_value']='1';
$dictionary['Account']['fields']['googleplus']['merge_filter']='disabled';
$dictionary['Account']['fields']['googleplus']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Account']['fields']['googleplus']['calculated']=false;

 ?>