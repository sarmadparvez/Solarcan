<?php
 // created: 2018-01-23 15:41:07
$dictionary['Account']['fields']['name']['len']='150';
$dictionary['Account']['fields']['name']['audited']=false;
$dictionary['Account']['fields']['name']['massupdate']=false;
$dictionary['Account']['fields']['name']['comments']='Name of the Company';
$dictionary['Account']['fields']['name']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['name']['duplicate_merge_dom_value']='1';
$dictionary['Account']['fields']['name']['merge_filter']='disabled';
$dictionary['Account']['fields']['name']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.91',
  'searchable' => true,
);
$dictionary['Account']['fields']['name']['calculated']=false;

 ?>