<?php
 // created: 2018-01-23 15:43:26
$dictionary['Account']['fields']['ticker_symbol']['len']='10';
$dictionary['Account']['fields']['ticker_symbol']['audited']=false;
$dictionary['Account']['fields']['ticker_symbol']['massupdate']=false;
$dictionary['Account']['fields']['ticker_symbol']['comments']='The stock trading (ticker) symbol for the company';
$dictionary['Account']['fields']['ticker_symbol']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['ticker_symbol']['duplicate_merge_dom_value']='1';
$dictionary['Account']['fields']['ticker_symbol']['merge_filter']='disabled';
$dictionary['Account']['fields']['ticker_symbol']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Account']['fields']['ticker_symbol']['calculated']=false;

 ?>