<?php
 // created: 2018-01-25 12:39:10
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['name']='nombre_fenetres_achanger';
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['vname']='LBL_NOMBRE_FENETRES_ACHANGER';
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['type']='varchar';
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['dbType']='varchar';
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['massupdate']=false;
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['duplicate_merge']='disabled';
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['merge_filter']='disabled';
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['calculated']='1';
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['required']=false;
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['audited']=true;
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['importable']='false';
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['duplicate_merge_dom_value']=0;
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['formula']='related($accounts,"nombre_fenetres_achanger")';
$dictionary['Meeting']['fields']['nombre_fenetres_achanger']['enforced']=true;

 ?>