<?php

$dictionary['dsm_dnc_historic']['fields']['dsm_dnc_id'] = array(
    'name'              => 'dsm_dnc_id',
    'rname'             => 'id',
    'vname'             => 'LBL_DSM_DNC_ID',
    'type'              => 'id',
    'table'             => 'dsm_dnc',
    'isnull'            => 'true',
    'module'            => 'dsm_dnc',
    'dbType'            => 'id',
    'reportable'        => false,
    'massupdate'        => false,
    'duplicate_merge'   => 'disabled',
);
