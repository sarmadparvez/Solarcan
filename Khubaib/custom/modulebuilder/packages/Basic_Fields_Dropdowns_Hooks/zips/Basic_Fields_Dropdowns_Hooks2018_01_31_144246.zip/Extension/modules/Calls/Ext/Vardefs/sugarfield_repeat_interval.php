<?php
 // created: 2018-01-23 15:38:33
$dictionary['Call']['fields']['repeat_interval']['name']='repeat_interval';
$dictionary['Call']['fields']['repeat_interval']['vname']='LBL_REPEAT_INTERVAL';
$dictionary['Call']['fields']['repeat_interval']['type']='int';
$dictionary['Call']['fields']['repeat_interval']['dbType']='int';
$dictionary['Call']['fields']['repeat_interval']['massupdate']=false;
$dictionary['Call']['fields']['repeat_interval']['duplicate_merge']='enabled';
$dictionary['Call']['fields']['repeat_interval']['merge_filter']='enabled';
$dictionary['Call']['fields']['repeat_interval']['calculated']=false;
$dictionary['Call']['fields']['repeat_interval']['required']=false;
$dictionary['Call']['fields']['repeat_interval']['audited']=true;
$dictionary['Call']['fields']['repeat_interval']['importable']='true';
$dictionary['Call']['fields']['repeat_interval']['duplicate_merge_dom_value']='2';
$dictionary['Call']['fields']['repeat_interval']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>