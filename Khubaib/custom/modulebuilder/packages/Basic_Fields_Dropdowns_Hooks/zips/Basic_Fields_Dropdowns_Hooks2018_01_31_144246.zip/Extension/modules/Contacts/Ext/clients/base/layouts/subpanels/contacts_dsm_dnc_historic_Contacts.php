<?php
// created: 2018-01-29 11:53:15
$viewdefs['Contacts']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_CONTACTS_DSM_DNC_HISTORIC_FROM_DSM_DNC_HISTORIC_TITLE',
  'context' => 
  array (
    'link' => 'contacts_dsm_dnc_historic',
  ),
);