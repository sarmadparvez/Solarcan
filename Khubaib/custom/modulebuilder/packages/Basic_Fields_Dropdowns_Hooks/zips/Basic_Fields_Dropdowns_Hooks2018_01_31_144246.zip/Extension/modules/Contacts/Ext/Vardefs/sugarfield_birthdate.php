<?php
 // created: 2018-01-23 15:35:25
$dictionary['Contact']['fields']['birthdate']['audited']=false;
$dictionary['Contact']['fields']['birthdate']['comments']='The birthdate of the contact';
$dictionary['Contact']['fields']['birthdate']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['birthdate']['duplicate_merge_dom_value']='1';
$dictionary['Contact']['fields']['birthdate']['merge_filter']='disabled';
$dictionary['Contact']['fields']['birthdate']['calculated']=false;
$dictionary['Contact']['fields']['birthdate']['enable_range_search']=false;

 ?>