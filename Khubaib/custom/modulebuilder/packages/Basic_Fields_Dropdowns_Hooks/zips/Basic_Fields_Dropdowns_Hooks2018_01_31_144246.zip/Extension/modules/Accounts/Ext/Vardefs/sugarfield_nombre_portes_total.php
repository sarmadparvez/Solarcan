<?php
 // created: 2018-01-24 11:13:14
$dictionary['Account']['fields']['nombre_portes_total']['name']='nombre_portes_total';
$dictionary['Account']['fields']['nombre_portes_total']['vname']='LBL_NOMBRE_PORTES_TOTAL';
$dictionary['Account']['fields']['nombre_portes_total']['type']='varchar';
$dictionary['Account']['fields']['nombre_portes_total']['dbType']='varchar';
$dictionary['Account']['fields']['nombre_portes_total']['massupdate']=false;
$dictionary['Account']['fields']['nombre_portes_total']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['nombre_portes_total']['merge_filter']='enabled';
$dictionary['Account']['fields']['nombre_portes_total']['calculated']=false;
$dictionary['Account']['fields']['nombre_portes_total']['required']=true;
$dictionary['Account']['fields']['nombre_portes_total']['audited']=true;
$dictionary['Account']['fields']['nombre_portes_total']['importable']='true';
$dictionary['Account']['fields']['nombre_portes_total']['duplicate_merge_dom_value']='2';
$dictionary['Account']['fields']['nombre_portes_total']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>