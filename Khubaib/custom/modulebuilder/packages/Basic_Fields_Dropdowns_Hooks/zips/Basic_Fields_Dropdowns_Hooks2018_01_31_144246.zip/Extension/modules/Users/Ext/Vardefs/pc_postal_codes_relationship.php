<?php

$dictionary['User']['fields']['pc_postal_codes_users'] = array(
    'name' => 'pc_postal_codes_users',
    'type' => 'link',
    'relationship' => 'pc_postal_codes_users',
    'module' => 'pc_postal_codes',
    'bean_name' => 'pc_postal_codes',
    'source' => 'non-db',
    'vname' => 'LBL_PC_POSTAL_CODES',
);
