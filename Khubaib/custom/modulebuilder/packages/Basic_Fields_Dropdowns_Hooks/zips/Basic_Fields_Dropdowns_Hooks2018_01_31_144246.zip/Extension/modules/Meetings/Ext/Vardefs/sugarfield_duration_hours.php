<?php

$dictionary['Meeting']['fields']['duration_hours'] = array(
    'name' => 'duration_hours',
    'vname' => 'LBL_DURATION_HOURS',
    'type' => 'int',
    'dbType' => 'int',
    'default' => NULL,
    'audited' => true,
    'mass_update' => false,
    'duplicate_merge' => true,
    'reportable' => true,
    'importable' => 'false',
);
