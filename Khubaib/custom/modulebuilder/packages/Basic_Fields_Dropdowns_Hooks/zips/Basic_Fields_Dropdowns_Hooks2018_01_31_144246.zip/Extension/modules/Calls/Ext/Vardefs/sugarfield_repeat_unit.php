<?php
 // created: 2018-01-23 19:12:05
$dictionary['Call']['fields']['repeat_unit']['name']='repeat_unit';
$dictionary['Call']['fields']['repeat_unit']['vname']='LBL_REPEAT_UNIT';
$dictionary['Call']['fields']['repeat_unit']['type']='varchar';
$dictionary['Call']['fields']['repeat_unit']['dbType']='varchar';
$dictionary['Call']['fields']['repeat_unit']['massupdate']=false;
$dictionary['Call']['fields']['repeat_unit']['duplicate_merge']='enabled';
$dictionary['Call']['fields']['repeat_unit']['merge_filter']='enabled';
$dictionary['Call']['fields']['repeat_unit']['calculated']=false;
$dictionary['Call']['fields']['repeat_unit']['required']=false;
$dictionary['Call']['fields']['repeat_unit']['audited']=true;
$dictionary['Call']['fields']['repeat_unit']['importable']='true';
$dictionary['Call']['fields']['repeat_unit']['duplicate_merge_dom_value']='2';
$dictionary['Call']['fields']['repeat_unit']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>