<?php
 // created: 2018-01-23 14:49:51
$dictionary['Contact']['fields']['preferred_language']['name']='preferred_language';
$dictionary['Contact']['fields']['preferred_language']['vname']='LBL_PREFERRED_LANGUAGE';
$dictionary['Contact']['fields']['preferred_language']['type']='enum';
$dictionary['Contact']['fields']['preferred_language']['options']='preferred_language_dom';
$dictionary['Contact']['fields']['preferred_language']['massupdate']=false;
$dictionary['Contact']['fields']['preferred_language']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['preferred_language']['merge_filter']='enabled';
$dictionary['Contact']['fields']['preferred_language']['calculated']=false;
$dictionary['Contact']['fields']['preferred_language']['required']=true;
$dictionary['Contact']['fields']['preferred_language']['audited']=true;
$dictionary['Contact']['fields']['preferred_language']['importable']='true';
$dictionary['Contact']['fields']['preferred_language']['duplicate_merge_dom_value']='2';

 ?>