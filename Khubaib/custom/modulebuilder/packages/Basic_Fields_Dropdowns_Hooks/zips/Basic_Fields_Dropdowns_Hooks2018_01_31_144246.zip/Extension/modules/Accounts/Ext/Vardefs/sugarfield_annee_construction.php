<?php
 // created: 2018-01-24 11:09:54
$dictionary['Account']['fields']['annee_construction']['name']='annee_construction';
$dictionary['Account']['fields']['annee_construction']['vname']='LBL_ANNEE_CONSTRUCTION';
$dictionary['Account']['fields']['annee_construction']['type']='varchar';
$dictionary['Account']['fields']['annee_construction']['dbType']='varchar';
$dictionary['Account']['fields']['annee_construction']['massupdate']=false;
$dictionary['Account']['fields']['annee_construction']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['annee_construction']['merge_filter']='enabled';
$dictionary['Account']['fields']['annee_construction']['calculated']=false;
$dictionary['Account']['fields']['annee_construction']['required']=true;
$dictionary['Account']['fields']['annee_construction']['audited']=true;
$dictionary['Account']['fields']['annee_construction']['importable']='true';
$dictionary['Account']['fields']['annee_construction']['duplicate_merge_dom_value']='2';
$dictionary['Account']['fields']['annee_construction']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>