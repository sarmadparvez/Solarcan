<?php
 // created: 2018-01-23 15:43:21
$dictionary['Account']['fields']['employees']['len']='10';
$dictionary['Account']['fields']['employees']['audited']=false;
$dictionary['Account']['fields']['employees']['massupdate']=false;
$dictionary['Account']['fields']['employees']['comments']='Number of employees, varchar to accomodate for both number (100) or range (50-100)';
$dictionary['Account']['fields']['employees']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['employees']['duplicate_merge_dom_value']='1';
$dictionary['Account']['fields']['employees']['merge_filter']='disabled';
$dictionary['Account']['fields']['employees']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Account']['fields']['employees']['calculated']=false;

 ?>