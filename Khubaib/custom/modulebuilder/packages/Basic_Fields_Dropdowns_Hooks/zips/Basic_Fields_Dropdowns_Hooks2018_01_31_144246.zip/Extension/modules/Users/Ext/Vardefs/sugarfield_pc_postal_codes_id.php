<?php

$dictionary['User']['fields']['pc_postal_codes_id'] = array(
    'name'              => 'pc_postal_codes_id',
    'rname'             => 'id',
    'vname'             => 'LBL_PC_POSTAL_CODES_ID',
    'type'              => 'id',
    'table'             => 'pc_postal_codes',
    'isnull'            => 'true',
    'module'            => 'pc_postal_codes',
    'dbType'            => 'id',
    'reportable'        => false,
    'massupdate'        => false,
    'duplicate_merge'   => 'disabled',
);
