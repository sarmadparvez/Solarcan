<?php
 // created: 2018-01-23 16:18:00
$dictionary['Opportunity']['fields']['montant']['name']='montant';
$dictionary['Opportunity']['fields']['montant']['vname']='LBL_MONTANT';
$dictionary['Opportunity']['fields']['montant']['type']='varchar';
$dictionary['Opportunity']['fields']['montant']['dbType']='varchar';
$dictionary['Opportunity']['fields']['montant']['massupdate']=false;
$dictionary['Opportunity']['fields']['montant']['duplicate_merge']='enabled';
$dictionary['Opportunity']['fields']['montant']['merge_filter']='enabled';
$dictionary['Opportunity']['fields']['montant']['calculated']=false;
$dictionary['Opportunity']['fields']['montant']['required']=false;
$dictionary['Opportunity']['fields']['montant']['audited']=true;
$dictionary['Opportunity']['fields']['montant']['importable']='true';
$dictionary['Opportunity']['fields']['montant']['duplicate_merge_dom_value']='2';
$dictionary['Opportunity']['fields']['montant']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>