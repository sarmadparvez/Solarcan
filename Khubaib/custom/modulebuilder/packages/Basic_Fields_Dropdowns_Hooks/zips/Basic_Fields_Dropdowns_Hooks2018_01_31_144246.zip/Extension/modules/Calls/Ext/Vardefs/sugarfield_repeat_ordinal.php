<?php
 // created: 2018-01-23 19:11:35
$dictionary['Call']['fields']['repeat_ordinal']['name']='repeat_ordinal';
$dictionary['Call']['fields']['repeat_ordinal']['vname']='LBL_REPEAT_ORDINAL';
$dictionary['Call']['fields']['repeat_ordinal']['type']='varchar';
$dictionary['Call']['fields']['repeat_ordinal']['dbType']='varchar';
$dictionary['Call']['fields']['repeat_ordinal']['massupdate']=false;
$dictionary['Call']['fields']['repeat_ordinal']['duplicate_merge']='enabled';
$dictionary['Call']['fields']['repeat_ordinal']['merge_filter']='enabled';
$dictionary['Call']['fields']['repeat_ordinal']['calculated']=false;
$dictionary['Call']['fields']['repeat_ordinal']['required']=false;
$dictionary['Call']['fields']['repeat_ordinal']['audited']=true;
$dictionary['Call']['fields']['repeat_ordinal']['importable']='true';
$dictionary['Call']['fields']['repeat_ordinal']['duplicate_merge_dom_value']='2';
$dictionary['Call']['fields']['repeat_ordinal']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>