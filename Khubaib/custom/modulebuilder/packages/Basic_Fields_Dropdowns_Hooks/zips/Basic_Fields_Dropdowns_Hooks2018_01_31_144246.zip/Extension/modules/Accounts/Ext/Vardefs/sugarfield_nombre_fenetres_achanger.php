<?php
 // created: 2018-01-24 11:10:09
$dictionary['Account']['fields']['nombre_fenetres_achanger']['name']='nombre_fenetres_achanger';
$dictionary['Account']['fields']['nombre_fenetres_achanger']['vname']='LBL_NOMBRE_FENETRES_ACHANGER';
$dictionary['Account']['fields']['nombre_fenetres_achanger']['type']='varchar';
$dictionary['Account']['fields']['nombre_fenetres_achanger']['dbType']='varchar';
$dictionary['Account']['fields']['nombre_fenetres_achanger']['massupdate']=false;
$dictionary['Account']['fields']['nombre_fenetres_achanger']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['nombre_fenetres_achanger']['merge_filter']='enabled';
$dictionary['Account']['fields']['nombre_fenetres_achanger']['calculated']=false;
$dictionary['Account']['fields']['nombre_fenetres_achanger']['required']=false;
$dictionary['Account']['fields']['nombre_fenetres_achanger']['audited']=true;
$dictionary['Account']['fields']['nombre_fenetres_achanger']['importable']='true';
$dictionary['Account']['fields']['nombre_fenetres_achanger']['duplicate_merge_dom_value']='2';
$dictionary['Account']['fields']['nombre_fenetres_achanger']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>