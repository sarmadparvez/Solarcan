<?php
 // created: 2018-01-25 12:05:05
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['name']='nombre_portes_achanger';
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['vname']='LBL_NOMBRE_PORTES_ACHANGER';
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['type']='varchar';
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['dbType']='varchar';
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['massupdate']=false;
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['duplicate_merge']='disabled';
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['calculated']='true';
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['required']=false;
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['audited']=true;
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['importable']='false';
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['duplicate_merge_dom_value']=0;
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['formula']='related($accounts,"nombre_portes_achanger")';
$dictionary['Opportunity']['fields']['nombre_portes_achanger']['enforced']=true;

 ?>