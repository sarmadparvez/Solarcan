<?php
 // created: 2018-01-23 15:38:33
$dictionary['Call']['fields']['recurring_source']['name']='recurring_source';
$dictionary['Call']['fields']['recurring_source']['vname']='LBL_RECURRING_SOURCE';
$dictionary['Call']['fields']['recurring_source']['type']='varchar';
$dictionary['Call']['fields']['recurring_source']['dbType']='varchar';
$dictionary['Call']['fields']['recurring_source']['massupdate']=false;
$dictionary['Call']['fields']['recurring_source']['duplicate_merge']='enabled';
$dictionary['Call']['fields']['recurring_source']['merge_filter']='enabled';
$dictionary['Call']['fields']['recurring_source']['calculated']=false;
$dictionary['Call']['fields']['recurring_source']['required']=false;
$dictionary['Call']['fields']['recurring_source']['audited']=true;
$dictionary['Call']['fields']['recurring_source']['importable']='true';
$dictionary['Call']['fields']['recurring_source']['duplicate_merge_dom_value']='2';
$dictionary['Call']['fields']['recurring_source']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>