<?php
 // created: 2018-01-24 19:47:42
$dictionary['dsm_suivi_de_vente']['fields']['status']['name']='status';
$dictionary['dsm_suivi_de_vente']['fields']['status']['vname']='LBL_STATUS';
$dictionary['dsm_suivi_de_vente']['fields']['status']['type']='varchar';
$dictionary['dsm_suivi_de_vente']['fields']['status']['dbType']='varchar';
$dictionary['dsm_suivi_de_vente']['fields']['status']['massupdate']=false;
$dictionary['dsm_suivi_de_vente']['fields']['status']['duplicate_merge']='enabled';
$dictionary['dsm_suivi_de_vente']['fields']['status']['merge_filter']='enabled';
$dictionary['dsm_suivi_de_vente']['fields']['status']['calculated']=false;
$dictionary['dsm_suivi_de_vente']['fields']['status']['required']=true;
$dictionary['dsm_suivi_de_vente']['fields']['status']['audited']=true;
$dictionary['dsm_suivi_de_vente']['fields']['status']['importable']='true';
$dictionary['dsm_suivi_de_vente']['fields']['status']['duplicate_merge_dom_value']='2';
$dictionary['dsm_suivi_de_vente']['fields']['status']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['dsm_suivi_de_vente']['fields']['status']['unified_search']=false;
