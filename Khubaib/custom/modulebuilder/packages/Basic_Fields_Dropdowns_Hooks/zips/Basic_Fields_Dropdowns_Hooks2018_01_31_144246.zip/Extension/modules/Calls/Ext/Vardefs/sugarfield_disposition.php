<?php
 // created: 2018-01-24 15:31:03
$dictionary['Call']['fields']['disposition']['name']='disposition';
$dictionary['Call']['fields']['disposition']['vname']='LBL_DISPOSITION';
$dictionary['Call']['fields']['disposition']['type']='enum';
$dictionary['Call']['fields']['disposition']['options']='disposition_dom';
$dictionary['Call']['fields']['disposition']['massupdate']=false;
$dictionary['Call']['fields']['disposition']['duplicate_merge']='enabled';
$dictionary['Call']['fields']['disposition']['merge_filter']='enabled';
$dictionary['Call']['fields']['disposition']['calculated']=false;
$dictionary['Call']['fields']['disposition']['required']=true;
$dictionary['Call']['fields']['disposition']['audited']=true;
$dictionary['Call']['fields']['disposition']['importable']='true';
$dictionary['Call']['fields']['disposition']['duplicate_merge_dom_value']='2';
$dictionary['Call']['fields']['disposition']['dependency']=false;

 ?>