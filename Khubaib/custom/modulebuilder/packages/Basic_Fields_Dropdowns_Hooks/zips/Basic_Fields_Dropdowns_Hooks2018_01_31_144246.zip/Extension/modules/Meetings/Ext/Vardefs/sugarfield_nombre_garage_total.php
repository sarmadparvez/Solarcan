<?php
 // created: 2018-01-25 12:39:34
$dictionary['Meeting']['fields']['nombre_garage_total']['name']='nombre_garage_total';
$dictionary['Meeting']['fields']['nombre_garage_total']['vname']='LBL_NOMBRE_GARAGE_TOTAL';
$dictionary['Meeting']['fields']['nombre_garage_total']['type']='varchar';
$dictionary['Meeting']['fields']['nombre_garage_total']['dbType']='varchar';
$dictionary['Meeting']['fields']['nombre_garage_total']['massupdate']=false;
$dictionary['Meeting']['fields']['nombre_garage_total']['duplicate_merge']='disabled';
$dictionary['Meeting']['fields']['nombre_garage_total']['merge_filter']='disabled';
$dictionary['Meeting']['fields']['nombre_garage_total']['calculated']='1';
$dictionary['Meeting']['fields']['nombre_garage_total']['required']=false;
$dictionary['Meeting']['fields']['nombre_garage_total']['audited']=true;
$dictionary['Meeting']['fields']['nombre_garage_total']['importable']='false';
$dictionary['Meeting']['fields']['nombre_garage_total']['duplicate_merge_dom_value']=0;
$dictionary['Meeting']['fields']['nombre_garage_total']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Meeting']['fields']['nombre_garage_total']['formula']='related($accounts,"nombre_garage_total")';
$dictionary['Meeting']['fields']['nombre_garage_total']['enforced']=true;

 ?>