<?php
 // created: 2018-01-23 15:30:45
$dictionary['Contact']['fields']['phone_other']['len']='100';
$dictionary['Contact']['fields']['phone_other']['audited']=false;
$dictionary['Contact']['fields']['phone_other']['massupdate']=false;
$dictionary['Contact']['fields']['phone_other']['comments']='Other phone number for the contact';
$dictionary['Contact']['fields']['phone_other']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['phone_other']['duplicate_merge_dom_value']='1';
$dictionary['Contact']['fields']['phone_other']['merge_filter']='disabled';
$dictionary['Contact']['fields']['phone_other']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.07',
  'searchable' => true,
);
$dictionary['Contact']['fields']['phone_other']['calculated']=false;

 ?>