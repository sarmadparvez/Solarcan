<?php
 // created: 2018-01-30 17:58:15
$dictionary['User']['fields']['can_sell']['name']='can_sell';
$dictionary['User']['fields']['can_sell']['vname']='LBL_CAN_SELL';
$dictionary['User']['fields']['can_sell']['type']='multienum';
$dictionary['User']['fields']['can_sell']['isMultiSelect']=true;
$dictionary['User']['fields']['can_sell']['options']='user_can_sell_dom';
$dictionary['User']['fields']['can_sell']['massupdate']=false;
$dictionary['User']['fields']['can_sell']['duplicate_merge']='enabled';
$dictionary['User']['fields']['can_sell']['merge_filter']='enabled';
$dictionary['User']['fields']['can_sell']['calculated']=false;
$dictionary['User']['fields']['can_sell']['required']=false;
$dictionary['User']['fields']['can_sell']['audited']=true;
$dictionary['User']['fields']['can_sell']['importable']='true';
$dictionary['User']['fields']['can_sell']['duplicate_merge_dom_value']='2';
$dictionary['User']['fields']['can_sell']['unified_search']=false;
$dictionary['User']['fields']['can_sell']['dependency']='';
$dictionary['User']['fields']['can_sell']['default']='^^';

 ?>