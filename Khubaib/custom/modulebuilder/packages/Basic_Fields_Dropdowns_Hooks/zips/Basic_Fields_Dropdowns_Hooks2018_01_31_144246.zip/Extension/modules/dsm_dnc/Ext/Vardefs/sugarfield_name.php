<?php
 // created: 2018-01-24 18:50:26
$dictionary['dsm_dnc']['fields']['name']['len']='255';
$dictionary['dsm_dnc']['fields']['name']['audited']=false;
$dictionary['dsm_dnc']['fields']['name']['massupdate']=false;
$dictionary['dsm_dnc']['fields']['name']['unified_search']=false;
$dictionary['dsm_dnc']['fields']['name']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.55',
  'searchable' => true,
);
$dictionary['dsm_dnc']['fields']['name']['calculated']=false;

 ?>