<?php
 // created: 2018-01-25 15:42:08
$dictionary['dsm_suivi_de_vente']['fields']['depot']['name']='depot';
$dictionary['dsm_suivi_de_vente']['fields']['depot']['vname']='LBL_DEPOT';
$dictionary['dsm_suivi_de_vente']['fields']['depot']['type']='varchar';
$dictionary['dsm_suivi_de_vente']['fields']['depot']['dbType']='varchar';
$dictionary['dsm_suivi_de_vente']['fields']['depot']['massupdate']=false;
$dictionary['dsm_suivi_de_vente']['fields']['depot']['duplicate_merge']='enabled';
$dictionary['dsm_suivi_de_vente']['fields']['depot']['merge_filter']='enabled';
$dictionary['dsm_suivi_de_vente']['fields']['depot']['calculated']=false;
$dictionary['dsm_suivi_de_vente']['fields']['depot']['required']=true;
$dictionary['dsm_suivi_de_vente']['fields']['depot']['audited']=true;
$dictionary['dsm_suivi_de_vente']['fields']['depot']['importable']='true';
$dictionary['dsm_suivi_de_vente']['fields']['depot']['duplicate_merge_dom_value']='2';
$dictionary['dsm_suivi_de_vente']['fields']['depot']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['dsm_suivi_de_vente']['fields']['depot']['unified_search']=false;

 ?>