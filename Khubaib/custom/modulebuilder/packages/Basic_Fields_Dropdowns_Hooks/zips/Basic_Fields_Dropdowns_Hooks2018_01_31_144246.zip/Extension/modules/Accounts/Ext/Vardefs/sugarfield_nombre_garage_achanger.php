<?php
 // created: 2018-01-24 12:44:48
$dictionary['Account']['fields']['nombre_garage_achanger']['name']='nombre_garage_achanger';
$dictionary['Account']['fields']['nombre_garage_achanger']['vname']='LBL_NOMBRE_GARAGE_ACHANGER';
$dictionary['Account']['fields']['nombre_garage_achanger']['type']='varchar';
$dictionary['Account']['fields']['nombre_garage_achanger']['dbType']='varchar';
$dictionary['Account']['fields']['nombre_garage_achanger']['massupdate']=false;
$dictionary['Account']['fields']['nombre_garage_achanger']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['nombre_garage_achanger']['merge_filter']='enabled';
$dictionary['Account']['fields']['nombre_garage_achanger']['calculated']=false;
$dictionary['Account']['fields']['nombre_garage_achanger']['required']=false;
$dictionary['Account']['fields']['nombre_garage_achanger']['audited']=true;
$dictionary['Account']['fields']['nombre_garage_achanger']['importable']='true';
$dictionary['Account']['fields']['nombre_garage_achanger']['duplicate_merge_dom_value']='2';
$dictionary['Account']['fields']['nombre_garage_achanger']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>