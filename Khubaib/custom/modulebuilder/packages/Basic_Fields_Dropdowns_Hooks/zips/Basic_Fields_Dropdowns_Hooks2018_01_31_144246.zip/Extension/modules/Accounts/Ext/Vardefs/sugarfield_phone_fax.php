<?php
 // created: 2018-01-23 15:33:09
$dictionary['Account']['fields']['phone_fax']['len']='100';
$dictionary['Account']['fields']['phone_fax']['audited']=false;
$dictionary['Account']['fields']['phone_fax']['massupdate']=false;
$dictionary['Account']['fields']['phone_fax']['comments']='The fax phone number of this company';
$dictionary['Account']['fields']['phone_fax']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['phone_fax']['duplicate_merge_dom_value']='1';
$dictionary['Account']['fields']['phone_fax']['merge_filter']='disabled';
$dictionary['Account']['fields']['phone_fax']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.04',
  'searchable' => true,
);
$dictionary['Account']['fields']['phone_fax']['calculated']=false;

 ?>