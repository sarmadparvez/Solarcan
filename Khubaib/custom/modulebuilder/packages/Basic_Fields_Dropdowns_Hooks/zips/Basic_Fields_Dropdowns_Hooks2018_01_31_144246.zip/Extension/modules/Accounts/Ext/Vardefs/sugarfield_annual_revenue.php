<?php
 // created: 2018-01-23 15:42:02
$dictionary['Account']['fields']['annual_revenue']['len']='100';
$dictionary['Account']['fields']['annual_revenue']['audited']=false;
$dictionary['Account']['fields']['annual_revenue']['massupdate']=false;
$dictionary['Account']['fields']['annual_revenue']['comments']='Annual revenue for this company';
$dictionary['Account']['fields']['annual_revenue']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['annual_revenue']['duplicate_merge_dom_value']='1';
$dictionary['Account']['fields']['annual_revenue']['merge_filter']='disabled';
$dictionary['Account']['fields']['annual_revenue']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Account']['fields']['annual_revenue']['calculated']=false;

 ?>