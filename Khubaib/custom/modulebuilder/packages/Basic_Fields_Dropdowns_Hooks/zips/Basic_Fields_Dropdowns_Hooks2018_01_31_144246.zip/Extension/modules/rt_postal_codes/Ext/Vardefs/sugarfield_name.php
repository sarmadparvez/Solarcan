<?php
 // created: 2018-01-31 12:41:14
$dictionary['rt_postal_codes']['fields']['name']['len']='255';
$dictionary['rt_postal_codes']['fields']['name']['required']=true;
$dictionary['rt_postal_codes']['fields']['name']['audited']=false;
$dictionary['rt_postal_codes']['fields']['name']['massupdate']=false;
$dictionary['rt_postal_codes']['fields']['name']['unified_search']=false;
$dictionary['rt_postal_codes']['fields']['name']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.55',
  'searchable' => true,
);
$dictionary['rt_postal_codes']['fields']['name']['calculated']=false;

 ?>