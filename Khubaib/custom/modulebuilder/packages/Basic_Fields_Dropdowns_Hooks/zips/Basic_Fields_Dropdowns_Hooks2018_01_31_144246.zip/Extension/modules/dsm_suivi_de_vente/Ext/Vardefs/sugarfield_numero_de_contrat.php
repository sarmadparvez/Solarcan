<?php
 // created: 2018-01-25 15:41:47
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_contrat']['name']='numero_de_contrat';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_contrat']['vname']='LBL_NUMERO_DE_CONTRAT';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_contrat']['type']='varchar';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_contrat']['dbType']='varchar';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_contrat']['massupdate']=false;
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_contrat']['duplicate_merge']='enabled';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_contrat']['merge_filter']='enabled';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_contrat']['calculated']=false;
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_contrat']['required']=true;
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_contrat']['audited']=true;
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_contrat']['importable']='true';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_contrat']['duplicate_merge_dom_value']='2';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_contrat']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_contrat']['unified_search']=false;

 ?>