<?php
 // created: 2018-01-24 11:13:02
$dictionary['Account']['fields']['nombre_portes_achanger']['name']='nombre_portes_achanger';
$dictionary['Account']['fields']['nombre_portes_achanger']['vname']='LBL_NOMBRE_PORTES_ACHANGER';
$dictionary['Account']['fields']['nombre_portes_achanger']['type']='varchar';
$dictionary['Account']['fields']['nombre_portes_achanger']['dbType']='varchar';
$dictionary['Account']['fields']['nombre_portes_achanger']['massupdate']=false;
$dictionary['Account']['fields']['nombre_portes_achanger']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['nombre_portes_achanger']['merge_filter']='enabled';
$dictionary['Account']['fields']['nombre_portes_achanger']['calculated']=false;
$dictionary['Account']['fields']['nombre_portes_achanger']['required']=false;
$dictionary['Account']['fields']['nombre_portes_achanger']['audited']=true;
$dictionary['Account']['fields']['nombre_portes_achanger']['importable']='true';
$dictionary['Account']['fields']['nombre_portes_achanger']['duplicate_merge_dom_value']='2';
$dictionary['Account']['fields']['nombre_portes_achanger']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>