<?php
 // created: 2018-01-23 15:35:19
$dictionary['Contact']['fields']['dnb_principal_id']['len']='30';
$dictionary['Contact']['fields']['dnb_principal_id']['audited']=false;
$dictionary['Contact']['fields']['dnb_principal_id']['massupdate']=false;
$dictionary['Contact']['fields']['dnb_principal_id']['comments']='Unique Id For D&B Contact';
$dictionary['Contact']['fields']['dnb_principal_id']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['dnb_principal_id']['duplicate_merge_dom_value']='1';
$dictionary['Contact']['fields']['dnb_principal_id']['merge_filter']='disabled';
$dictionary['Contact']['fields']['dnb_principal_id']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Contact']['fields']['dnb_principal_id']['calculated']=false;

 ?>