<?php
 // created: 2018-01-23 15:29:54
$dictionary['Contact']['fields']['department']['audited']=false;
$dictionary['Contact']['fields']['department']['massupdate']=false;
$dictionary['Contact']['fields']['department']['comments']='The department of the contact';
$dictionary['Contact']['fields']['department']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['department']['duplicate_merge_dom_value']='1';
$dictionary['Contact']['fields']['department']['merge_filter']='disabled';
$dictionary['Contact']['fields']['department']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Contact']['fields']['department']['calculated']=false;

 ?>