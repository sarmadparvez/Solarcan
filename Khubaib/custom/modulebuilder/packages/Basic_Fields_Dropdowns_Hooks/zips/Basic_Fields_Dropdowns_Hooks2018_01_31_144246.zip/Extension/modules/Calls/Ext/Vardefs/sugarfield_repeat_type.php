<?php
 // created: 2018-01-23 15:38:33
$dictionary['Call']['fields']['repeat_type']['name']='repeat_type';
$dictionary['Call']['fields']['repeat_type']['vname']='LBL_REPEAT_TYPE';
$dictionary['Call']['fields']['repeat_type']['type']='varchar';
$dictionary['Call']['fields']['repeat_type']['dbType']='varchar';
$dictionary['Call']['fields']['repeat_type']['massupdate']=false;
$dictionary['Call']['fields']['repeat_type']['duplicate_merge']='enabled';
$dictionary['Call']['fields']['repeat_type']['merge_filter']='enabled';
$dictionary['Call']['fields']['repeat_type']['calculated']=false;
$dictionary['Call']['fields']['repeat_type']['required']=false;
$dictionary['Call']['fields']['repeat_type']['audited']=true;
$dictionary['Call']['fields']['repeat_type']['importable']='true';
$dictionary['Call']['fields']['repeat_type']['duplicate_merge_dom_value']='2';
$dictionary['Call']['fields']['repeat_type']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>