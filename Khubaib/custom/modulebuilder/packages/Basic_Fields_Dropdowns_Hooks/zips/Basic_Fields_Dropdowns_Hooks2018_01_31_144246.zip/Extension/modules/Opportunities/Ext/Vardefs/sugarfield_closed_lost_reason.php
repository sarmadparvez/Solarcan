<?php
 // created: 2018-01-24 13:02:16
$dictionary['Opportunity']['fields']['closed_lost_reason']['name']='closed_lost_reason';
$dictionary['Opportunity']['fields']['closed_lost_reason']['vname']='LBL_CLOSED_LOST_REASON';
$dictionary['Opportunity']['fields']['closed_lost_reason']['type']='enum';
$dictionary['Opportunity']['fields']['closed_lost_reason']['options']='closed_lost_reason_dom';
$dictionary['Opportunity']['fields']['closed_lost_reason']['massupdate']=false;
$dictionary['Opportunity']['fields']['closed_lost_reason']['duplicate_merge']='enabled';
$dictionary['Opportunity']['fields']['closed_lost_reason']['merge_filter']='enabled';
$dictionary['Opportunity']['fields']['closed_lost_reason']['calculated']=false;
$dictionary['Opportunity']['fields']['closed_lost_reason']['required']=true;
$dictionary['Opportunity']['fields']['closed_lost_reason']['audited']=true;
$dictionary['Opportunity']['fields']['closed_lost_reason']['importable']='true';
$dictionary['Opportunity']['fields']['closed_lost_reason']['duplicate_merge_dom_value']='2';
$dictionary['Opportunity']['fields']['closed_lost_reason']['default']='autres';
$dictionary['Opportunity']['fields']['closed_lost_reason']['dependency']=false;

 ?>