<?php
 // created: 2018-01-25 12:40:23
$dictionary['Meeting']['fields']['source']['name']='source';
$dictionary['Meeting']['fields']['source']['vname']='LBL_SOURCE';
$dictionary['Meeting']['fields']['source']['type']='enum';
$dictionary['Meeting']['fields']['source']['massupdate']=true;
$dictionary['Meeting']['fields']['source']['duplicate_merge']='enabled';
$dictionary['Meeting']['fields']['source']['merge_filter']='enabled';
$dictionary['Meeting']['fields']['source']['calculated']=false;
$dictionary['Meeting']['fields']['source']['required']=false;
$dictionary['Meeting']['fields']['source']['len']=100;
$dictionary['Meeting']['fields']['source']['audited']=true;
$dictionary['Meeting']['fields']['source']['importable']='true';
$dictionary['Meeting']['fields']['source']['options']='source_dom';
$dictionary['Meeting']['fields']['source']['duplicate_merge_dom_value']='2';
$dictionary['Meeting']['fields']['source']['dependency']=false;

 ?>