<?php
$dictionary['Meeting']['fields']['revenuelineitems']['workflow'] = true;