<?php
 // created: 2018-01-25 12:40:05
$dictionary['Meeting']['fields']['email']['name']='email';
$dictionary['Meeting']['fields']['email']['vname']='LBL_EMAIL';
$dictionary['Meeting']['fields']['email']['type']='varchar';
$dictionary['Meeting']['fields']['email']['dbType']='varchar';
$dictionary['Meeting']['fields']['email']['massupdate']=false;
$dictionary['Meeting']['fields']['email']['duplicate_merge']='enabled';
$dictionary['Meeting']['fields']['email']['merge_filter']='enabled';
$dictionary['Meeting']['fields']['email']['calculated']=false;
$dictionary['Meeting']['fields']['email']['required']=false;
$dictionary['Meeting']['fields']['email']['audited']=true;
$dictionary['Meeting']['fields']['email']['importable']='true';
$dictionary['Meeting']['fields']['email']['duplicate_merge_dom_value']='2';
$dictionary['Meeting']['fields']['email']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>