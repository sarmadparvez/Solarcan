<?php
 // created: 2018-01-25 12:39:42
$dictionary['Meeting']['fields']['nombre_portes_achanger']['name']='nombre_portes_achanger';
$dictionary['Meeting']['fields']['nombre_portes_achanger']['vname']='LBL_NOMBRE_PORTES_ACHANGER';
$dictionary['Meeting']['fields']['nombre_portes_achanger']['type']='varchar';
$dictionary['Meeting']['fields']['nombre_portes_achanger']['dbType']='varchar';
$dictionary['Meeting']['fields']['nombre_portes_achanger']['massupdate']=false;
$dictionary['Meeting']['fields']['nombre_portes_achanger']['duplicate_merge']='disabled';
$dictionary['Meeting']['fields']['nombre_portes_achanger']['merge_filter']='disabled';
$dictionary['Meeting']['fields']['nombre_portes_achanger']['calculated']='1';
$dictionary['Meeting']['fields']['nombre_portes_achanger']['required']=false;
$dictionary['Meeting']['fields']['nombre_portes_achanger']['audited']=true;
$dictionary['Meeting']['fields']['nombre_portes_achanger']['importable']='false';
$dictionary['Meeting']['fields']['nombre_portes_achanger']['duplicate_merge_dom_value']=0;
$dictionary['Meeting']['fields']['nombre_portes_achanger']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Meeting']['fields']['nombre_portes_achanger']['formula']='related($accounts,"nombre_portes_achanger")';
$dictionary['Meeting']['fields']['nombre_portes_achanger']['enforced']=true;

 ?>