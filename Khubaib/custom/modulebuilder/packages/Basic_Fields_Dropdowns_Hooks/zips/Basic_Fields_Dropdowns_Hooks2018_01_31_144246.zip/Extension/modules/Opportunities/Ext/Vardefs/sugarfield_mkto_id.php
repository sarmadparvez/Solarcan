<?php
 // created: 2018-01-23 15:54:35
$dictionary['Opportunity']['fields']['mkto_id']['audited']=false;
$dictionary['Opportunity']['fields']['mkto_id']['massupdate']=false;
$dictionary['Opportunity']['fields']['mkto_id']['comments']='Associated Marketo Lead ID';
$dictionary['Opportunity']['fields']['mkto_id']['duplicate_merge']='enabled';
$dictionary['Opportunity']['fields']['mkto_id']['duplicate_merge_dom_value']='1';
$dictionary['Opportunity']['fields']['mkto_id']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['mkto_id']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Opportunity']['fields']['mkto_id']['calculated']=false;
$dictionary['Opportunity']['fields']['mkto_id']['enable_range_search']=false;
$dictionary['Opportunity']['fields']['mkto_id']['min']=false;
$dictionary['Opportunity']['fields']['mkto_id']['max']=false;
$dictionary['Opportunity']['fields']['mkto_id']['disable_num_format']='';

 ?>