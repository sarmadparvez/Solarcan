<?php
 // created: 2018-01-23 15:54:41
$dictionary['Opportunity']['fields']['mkto_sync']['default']=false;
$dictionary['Opportunity']['fields']['mkto_sync']['audited']=false;
$dictionary['Opportunity']['fields']['mkto_sync']['massupdate']=false;
$dictionary['Opportunity']['fields']['mkto_sync']['comments']='Should the Lead be synced to Marketo';
$dictionary['Opportunity']['fields']['mkto_sync']['duplicate_merge']='enabled';
$dictionary['Opportunity']['fields']['mkto_sync']['duplicate_merge_dom_value']='1';
$dictionary['Opportunity']['fields']['mkto_sync']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['mkto_sync']['unified_search']=false;
$dictionary['Opportunity']['fields']['mkto_sync']['calculated']=false;

 ?>