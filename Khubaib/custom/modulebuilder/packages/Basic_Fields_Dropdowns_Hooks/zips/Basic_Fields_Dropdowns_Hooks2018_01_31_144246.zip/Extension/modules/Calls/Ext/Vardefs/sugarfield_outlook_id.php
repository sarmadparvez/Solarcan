<?php
 // created: 2018-01-23 15:38:33
$dictionary['Call']['fields']['outlook_id']['name']='outlook_id';
$dictionary['Call']['fields']['outlook_id']['vname']='LBL_OUTLOOK_ID';
$dictionary['Call']['fields']['outlook_id']['type']='varchar';
$dictionary['Call']['fields']['outlook_id']['dbType']='varchar';
$dictionary['Call']['fields']['outlook_id']['massupdate']=false;
$dictionary['Call']['fields']['outlook_id']['duplicate_merge']='enabled';
$dictionary['Call']['fields']['outlook_id']['merge_filter']='enabled';
$dictionary['Call']['fields']['outlook_id']['calculated']=false;
$dictionary['Call']['fields']['outlook_id']['required']=false;
$dictionary['Call']['fields']['outlook_id']['audited']=true;
$dictionary['Call']['fields']['outlook_id']['importable']='true';
$dictionary['Call']['fields']['outlook_id']['duplicate_merge_dom_value']='2';
$dictionary['Call']['fields']['outlook_id']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>