<?php
 // created: 2018-01-23 15:38:33
$dictionary['Call']['fields']['repeat_parent_id']['name']='repeat_parent_id';
$dictionary['Call']['fields']['repeat_parent_id']['vname']='LBL_REPEAT_PARENT_ID';
$dictionary['Call']['fields']['repeat_parent_id']['type']='varchar';
$dictionary['Call']['fields']['repeat_parent_id']['dbType']='varchar';
$dictionary['Call']['fields']['repeat_parent_id']['massupdate']=false;
$dictionary['Call']['fields']['repeat_parent_id']['duplicate_merge']='enabled';
$dictionary['Call']['fields']['repeat_parent_id']['merge_filter']='enabled';
$dictionary['Call']['fields']['repeat_parent_id']['calculated']=false;
$dictionary['Call']['fields']['repeat_parent_id']['required']=false;
$dictionary['Call']['fields']['repeat_parent_id']['audited']=true;
$dictionary['Call']['fields']['repeat_parent_id']['importable']='true';
$dictionary['Call']['fields']['repeat_parent_id']['duplicate_merge_dom_value']='2';
$dictionary['Call']['fields']['repeat_parent_id']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>