<?php
 // created: 2018-01-23 15:27:40
$dictionary['Contact']['fields']['description']['audited']=false;
$dictionary['Contact']['fields']['description']['massupdate']=false;
$dictionary['Contact']['fields']['description']['comments']='Full text of the note';
$dictionary['Contact']['fields']['description']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['description']['duplicate_merge_dom_value']='1';
$dictionary['Contact']['fields']['description']['merge_filter']='disabled';
$dictionary['Contact']['fields']['description']['full_text_search']=array (
  'enabled' => true,
  'boost' => '0.71',
  'searchable' => true,
);
$dictionary['Contact']['fields']['description']['calculated']=false;
$dictionary['Contact']['fields']['description']['rows']='6';
$dictionary['Contact']['fields']['description']['cols']='80';

 ?>