<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_NAME'] = 'Name';
$mod_strings['LBL_STATUT_PRECEDENT'] = 'Statut précédent';
$mod_strings['LBL_DATE_ENREGISTREMENT'] = 'Date enregistrement';
$mod_strings['LBL_SOURCE_DETAILS_USER_ID'] = 'Source details (related User ID)';
$mod_strings['LBL_SOURCE_DETAILS'] = 'Source details';
$mod_strings['LBL_CONTACTS_DSM_DNC_HISTORIC_FROM_CONTACTS_TITLE'] = 'Contacts';
$mod_strings['LBL_DSM_DNC_HISTORIC'] = 'Contacts';
$mod_strings['LBL_CONTACT_NAME'] = 'Contact';
$mod_strings['LBL_MODIFIED_BY'] = 'Modified by';
$mod_strings['LBL_DSM_DNC_NAME'] = 'DNC';
