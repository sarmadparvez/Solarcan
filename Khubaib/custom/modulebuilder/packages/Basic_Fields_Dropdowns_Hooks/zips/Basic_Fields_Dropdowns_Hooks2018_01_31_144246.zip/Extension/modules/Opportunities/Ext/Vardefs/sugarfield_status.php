<?php
 // created: 2018-01-23 16:01:24
$dictionary['Opportunity']['fields']['status']['name']='status';
$dictionary['Opportunity']['fields']['status']['vname']='LBL_STATUS';
$dictionary['Opportunity']['fields']['status']['type']='enum';
$dictionary['Opportunity']['fields']['status']['options']='statut_apres_rencontre_dom';
$dictionary['Opportunity']['fields']['status']['massupdate']=false;
$dictionary['Opportunity']['fields']['status']['duplicate_merge']='enabled';
$dictionary['Opportunity']['fields']['status']['merge_filter']='enabled';
$dictionary['Opportunity']['fields']['status']['calculated']=false;
$dictionary['Opportunity']['fields']['status']['required']=true;
$dictionary['Opportunity']['fields']['status']['audited']=true;
$dictionary['Opportunity']['fields']['status']['importable']='true';
$dictionary['Opportunity']['fields']['status']['duplicate_merge_dom_value']='2';
$dictionary['Opportunity']['fields']['status']['default']='non_rencontre';
$dictionary['Opportunity']['fields']['status']['dependency']=false;

 ?>