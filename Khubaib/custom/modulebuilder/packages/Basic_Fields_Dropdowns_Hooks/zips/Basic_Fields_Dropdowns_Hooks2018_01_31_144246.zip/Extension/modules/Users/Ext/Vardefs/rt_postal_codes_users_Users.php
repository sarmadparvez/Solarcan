<?php
// created: 2018-01-31 12:37:05
$dictionary["User"]["fields"]["rt_postal_codes_users"] = array (
  'name' => 'rt_postal_codes_users',
  'type' => 'link',
  'relationship' => 'rt_postal_codes_users',
  'source' => 'non-db',
  'module' => 'rt_postal_codes',
  'bean_name' => false,
  'vname' => 'LBL_RT_POSTAL_CODES_USERS_FROM_RT_POSTAL_CODES_TITLE',
  'id_name' => 'rt_postal_codes_usersrt_postal_codes_ida',
);
