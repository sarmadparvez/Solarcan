<?php
// created: 2018-01-29 11:53:15
$viewdefs['dsm_dnc']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_DSM_DNC_DSM_DNC_HISTORIC_FROM_DSM_DNC_HISTORIC_TITLE',
  'context' => 
  array (
    'link' => 'dsm_dnc_dsm_dnc_historic',
  ),
);