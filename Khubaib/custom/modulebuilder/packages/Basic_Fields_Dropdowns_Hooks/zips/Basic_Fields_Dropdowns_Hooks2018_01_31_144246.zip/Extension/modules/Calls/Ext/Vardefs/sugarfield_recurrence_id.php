<?php
 // created: 2018-01-23 19:11:06
$dictionary['Call']['fields']['recurrence_id']['name']='recurrence_id';
$dictionary['Call']['fields']['recurrence_id']['vname']='LBL_RECURRENCE_ID';
$dictionary['Call']['fields']['recurrence_id']['type']='datetime';
$dictionary['Call']['fields']['recurrence_id']['massupdate']=false;
$dictionary['Call']['fields']['recurrence_id']['duplicate_merge']='enabled';
$dictionary['Call']['fields']['recurrence_id']['merge_filter']='enabled';
$dictionary['Call']['fields']['recurrence_id']['calculated']=false;
$dictionary['Call']['fields']['recurrence_id']['required']=false;
$dictionary['Call']['fields']['recurrence_id']['audited']=true;
$dictionary['Call']['fields']['recurrence_id']['importable']='true';
$dictionary['Call']['fields']['recurrence_id']['duplicate_merge_dom_value']='2';
$dictionary['Call']['fields']['recurrence_id']['enable_range_search']=false;

 ?>