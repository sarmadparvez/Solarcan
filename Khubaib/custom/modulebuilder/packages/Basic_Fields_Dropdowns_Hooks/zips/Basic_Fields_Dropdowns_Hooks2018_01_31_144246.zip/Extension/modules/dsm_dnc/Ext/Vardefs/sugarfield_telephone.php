<?php
 // created: 2018-01-24 19:33:25
$dictionary['dsm_dnc']['fields']['telephone']['name']='telephone';
$dictionary['dsm_dnc']['fields']['telephone']['vname']='LBL_TELEPHONE';
$dictionary['dsm_dnc']['fields']['telephone']['type']='varchar';
$dictionary['dsm_dnc']['fields']['telephone']['dbType']='varchar';
$dictionary['dsm_dnc']['fields']['telephone']['massupdate']=false;
$dictionary['dsm_dnc']['fields']['telephone']['duplicate_merge']='enabled';
$dictionary['dsm_dnc']['fields']['telephone']['merge_filter']='enabled';
$dictionary['dsm_dnc']['fields']['telephone']['calculated']=false;
$dictionary['dsm_dnc']['fields']['telephone']['required']=true;
$dictionary['dsm_dnc']['fields']['telephone']['audited']=true;
$dictionary['dsm_dnc']['fields']['telephone']['importable']='true';
$dictionary['dsm_dnc']['fields']['telephone']['duplicate_merge_dom_value']='2';
$dictionary['dsm_dnc']['fields']['telephone']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['dsm_dnc']['fields']['telephone']['unified_search']=false;

 ?>