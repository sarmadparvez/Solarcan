<?php
 // created: 2018-01-24 11:12:20
$dictionary['Account']['fields']['nombre_fenetres_total']['name']='nombre_fenetres_total';
$dictionary['Account']['fields']['nombre_fenetres_total']['vname']='LBL_NOMBRE_FENETRES_TOTAL';
$dictionary['Account']['fields']['nombre_fenetres_total']['type']='varchar';
$dictionary['Account']['fields']['nombre_fenetres_total']['dbType']='varchar';
$dictionary['Account']['fields']['nombre_fenetres_total']['massupdate']=false;
$dictionary['Account']['fields']['nombre_fenetres_total']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['nombre_fenetres_total']['merge_filter']='enabled';
$dictionary['Account']['fields']['nombre_fenetres_total']['calculated']=false;
$dictionary['Account']['fields']['nombre_fenetres_total']['required']=true;
$dictionary['Account']['fields']['nombre_fenetres_total']['audited']=true;
$dictionary['Account']['fields']['nombre_fenetres_total']['importable']='true';
$dictionary['Account']['fields']['nombre_fenetres_total']['duplicate_merge_dom_value']='2';
$dictionary['Account']['fields']['nombre_fenetres_total']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>