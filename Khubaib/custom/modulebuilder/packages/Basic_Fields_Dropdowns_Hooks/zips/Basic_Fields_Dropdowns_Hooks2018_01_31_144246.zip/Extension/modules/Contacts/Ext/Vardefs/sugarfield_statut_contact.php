<?php
 // created: 2018-01-23 15:38:12
$dictionary['Contact']['fields']['statut_contact']['name']='statut_contact';
$dictionary['Contact']['fields']['statut_contact']['vname']='LBL_STATUT_CONTACT';
$dictionary['Contact']['fields']['statut_contact']['type']='enum';
$dictionary['Contact']['fields']['statut_contact']['options']='statut_contact_dom';
$dictionary['Contact']['fields']['statut_contact']['massupdate']=false;
$dictionary['Contact']['fields']['statut_contact']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['statut_contact']['merge_filter']='enabled';
$dictionary['Contact']['fields']['statut_contact']['calculated']=false;
$dictionary['Contact']['fields']['statut_contact']['required']=true;
$dictionary['Contact']['fields']['statut_contact']['audited']=true;
$dictionary['Contact']['fields']['statut_contact']['importable']='true';
$dictionary['Contact']['fields']['statut_contact']['duplicate_merge_dom_value']='2';
$dictionary['Contact']['fields']['statut_contact']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
