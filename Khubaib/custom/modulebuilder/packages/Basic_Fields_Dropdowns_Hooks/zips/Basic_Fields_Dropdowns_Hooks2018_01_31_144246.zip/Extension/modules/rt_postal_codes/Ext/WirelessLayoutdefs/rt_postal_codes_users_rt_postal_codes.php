<?php
 // created: 2018-01-31 12:37:05
$layout_defs["rt_postal_codes"]["subpanel_setup"]['rt_postal_codes_users'] = array (
  'order' => 100,
  'module' => 'Users',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_RT_POSTAL_CODES_USERS_FROM_USERS_TITLE',
  'get_subpanel_data' => 'rt_postal_codes_users',
);
