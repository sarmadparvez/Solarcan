<?php
 // created: 2018-01-23 15:38:33
$dictionary['Call']['fields']['repeat_until']['name']='repeat_until';
$dictionary['Call']['fields']['repeat_until']['vname']='LBL_REPEAT_UNTIL';
$dictionary['Call']['fields']['repeat_until']['type']='datetime';
$dictionary['Call']['fields']['repeat_until']['massupdate']=false;
$dictionary['Call']['fields']['repeat_until']['duplicate_merge']='enabled';
$dictionary['Call']['fields']['repeat_until']['merge_filter']='enabled';
$dictionary['Call']['fields']['repeat_until']['calculated']=false;
$dictionary['Call']['fields']['repeat_until']['required']=false;
$dictionary['Call']['fields']['repeat_until']['audited']=true;
$dictionary['Call']['fields']['repeat_until']['importable']='true';
$dictionary['Call']['fields']['repeat_until']['duplicate_merge_dom_value']='2';
$dictionary['Call']['fields']['repeat_until']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>