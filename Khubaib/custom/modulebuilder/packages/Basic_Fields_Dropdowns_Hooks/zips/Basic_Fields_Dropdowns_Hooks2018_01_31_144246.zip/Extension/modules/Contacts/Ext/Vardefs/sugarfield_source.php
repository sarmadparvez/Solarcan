<?php
 // created: 2018-01-23 18:05:45
$dictionary['Contact']['fields']['source']['name']='source';
$dictionary['Contact']['fields']['source']['vname']='LBL_SOURCE';
$dictionary['Contact']['fields']['source']['type']='enum';
$dictionary['Contact']['fields']['source']['massupdate']=true;
$dictionary['Contact']['fields']['source']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['source']['merge_filter']='enabled';
$dictionary['Contact']['fields']['source']['calculated']=false;
$dictionary['Contact']['fields']['source']['required']=true;
$dictionary['Contact']['fields']['source']['len']=100;
$dictionary['Contact']['fields']['source']['audited']=true;
$dictionary['Contact']['fields']['source']['importable']='true';
$dictionary['Contact']['fields']['source']['options']='source_dom';
$dictionary['Contact']['fields']['source']['duplicate_merge_dom_value']='2';
$dictionary['Contact']['fields']['source']['dependency']=false;

 ?>