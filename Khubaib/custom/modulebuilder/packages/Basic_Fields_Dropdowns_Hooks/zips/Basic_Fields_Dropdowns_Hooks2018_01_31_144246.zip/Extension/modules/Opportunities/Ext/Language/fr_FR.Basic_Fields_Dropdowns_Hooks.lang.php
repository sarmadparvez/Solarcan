<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_ACCOUNT_NAME'] = 'Bâtiment Name:';
$mod_strings['LBL_ACCOUNT_ID'] = 'Bâtiment ID';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Bâtiment Name';
$mod_strings['LBL_MKTO_ID'] = 'Marketo Lead ID';
$mod_strings['LBL_MKTO_SYNC'] = 'Sync to Marketo&amp;reg;';
$mod_strings['LBL_STATUS'] = 'Status:';
$mod_strings['LBL_ANNEE_CONSTRUCTION'] = 'Année construction';
$mod_strings['LBL_NOMBRE_FENETRES_ACHANGER'] = 'Nombre fenetres achanger';
$mod_strings['LBL_NOMBRE_FENETRES_TOTAL'] = 'Nombre fenetres total';
$mod_strings['LBL_NOMBRE_GARAGE_ACHANGER'] = 'Nombre garage achanger';
$mod_strings['LBL_NOMBRE_GARAGE_TOTAL'] = 'Nombre garage total';
$mod_strings['LBL_NOMBRE_PORTES_ACHANGER'] = 'Nombre portes achanger';
$mod_strings['LBL_NOMBRE_PORTES_TOTAL'] = 'Nombre portes total';
$mod_strings['LBL_NUMERO_CONTRAT'] = 'Numero contrat';
$mod_strings['LBL_STATUT_APRES_VENTE'] = 'Statut après vente';
$mod_strings['LBL_MONTANT'] = 'Montant';
