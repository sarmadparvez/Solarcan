<?php
 // created: 2018-01-24 15:30:01
$dictionary['Meeting']['fields']['financement']['name']='financement';
$dictionary['Meeting']['fields']['financement']['vname']='LBL_FINANCEMENT';
$dictionary['Meeting']['fields']['financement']['type']='enum';
$dictionary['Meeting']['fields']['financement']['massupdate']=true;
$dictionary['Meeting']['fields']['financement']['duplicate_merge']='enabled';
$dictionary['Meeting']['fields']['financement']['merge_filter']='enabled';
$dictionary['Meeting']['fields']['financement']['calculated']=false;
$dictionary['Meeting']['fields']['financement']['required']=true;
$dictionary['Meeting']['fields']['financement']['len']=100;
$dictionary['Meeting']['fields']['financement']['audited']=true;
$dictionary['Meeting']['fields']['financement']['importable']='true';
$dictionary['Meeting']['fields']['financement']['options']='yes_no_dom';
$dictionary['Meeting']['fields']['financement']['duplicate_merge_dom_value']='2';
$dictionary['Meeting']['fields']['financement']['dependency']=false;

 ?>