<?php
 // created: 2018-01-23 19:11:49
$dictionary['Call']['fields']['repeat_selector']['name']='repeat_selector';
$dictionary['Call']['fields']['repeat_selector']['vname']='LBL_REPEAT_SELECTOR';
$dictionary['Call']['fields']['repeat_selector']['type']='varchar';
$dictionary['Call']['fields']['repeat_selector']['dbType']='varchar';
$dictionary['Call']['fields']['repeat_selector']['massupdate']=false;
$dictionary['Call']['fields']['repeat_selector']['duplicate_merge']='enabled';
$dictionary['Call']['fields']['repeat_selector']['merge_filter']='enabled';
$dictionary['Call']['fields']['repeat_selector']['calculated']=false;
$dictionary['Call']['fields']['repeat_selector']['required']=false;
$dictionary['Call']['fields']['repeat_selector']['audited']=true;
$dictionary['Call']['fields']['repeat_selector']['importable']='true';
$dictionary['Call']['fields']['repeat_selector']['duplicate_merge_dom_value']='2';
$dictionary['Call']['fields']['repeat_selector']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>