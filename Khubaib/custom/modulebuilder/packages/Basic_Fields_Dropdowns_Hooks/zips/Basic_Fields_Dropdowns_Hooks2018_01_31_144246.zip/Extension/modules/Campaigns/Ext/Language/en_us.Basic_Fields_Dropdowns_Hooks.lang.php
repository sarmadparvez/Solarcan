<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_CAMPAIGN_ACCOUNTS_SUBPANEL_TITLE'] = 'Bâtiments';
$mod_strings['LBL_ACCOUNTS'] = 'Bâtiments';
