<?php
 // created: 2018-01-23 15:44:07
$dictionary['Account']['fields']['sic_code']['len']='10';
$dictionary['Account']['fields']['sic_code']['audited']=false;
$dictionary['Account']['fields']['sic_code']['massupdate']=false;
$dictionary['Account']['fields']['sic_code']['comments']='SIC code of the account';
$dictionary['Account']['fields']['sic_code']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['sic_code']['duplicate_merge_dom_value']='1';
$dictionary['Account']['fields']['sic_code']['merge_filter']='disabled';
$dictionary['Account']['fields']['sic_code']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.21',
  'searchable' => true,
);
$dictionary['Account']['fields']['sic_code']['calculated']=false;

 ?>