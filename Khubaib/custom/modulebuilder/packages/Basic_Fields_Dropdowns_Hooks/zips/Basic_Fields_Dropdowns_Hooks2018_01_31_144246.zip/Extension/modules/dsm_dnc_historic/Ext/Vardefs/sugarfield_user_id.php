<?php

$dictionary["dsm_dnc_historic"]["fields"]["user_id"] = array(
    'inline_edit' => 0,
      'required' => false,
      'name' => 'user_id',
      'vname' => 'LBL_WOW_DNC_HISTORIC_USER_ID',
      'type' => 'id',
      'massupdate' => '0',
      'default' => NULL,
      'no_default' => false,
      'comments' => '',
      'help' => '',
      'importable' => 'true',
      'duplicate_merge' => 'disabled',
      'duplicate_merge_dom_value' => '0',
      'audited' => false,
      'reportable' => false,
      'unified_search' => false,
      'merge_filter' => 'disabled',
      'len' => '36',
      'size' => '20',
      'id' => 'dsm_dnc_historicuser_id',
);
