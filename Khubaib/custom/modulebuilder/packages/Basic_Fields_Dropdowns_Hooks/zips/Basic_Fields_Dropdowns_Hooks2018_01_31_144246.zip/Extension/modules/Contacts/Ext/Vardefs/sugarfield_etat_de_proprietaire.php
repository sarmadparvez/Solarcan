<?php
 // created: 2018-01-23 15:39:21
$dictionary['Contact']['fields']['etat_de_proprietaire']['name']='etat_de_proprietaire';
$dictionary['Contact']['fields']['etat_de_proprietaire']['vname']='LBL_ETAT_DE_PROPRIÉTAIRE';
$dictionary['Contact']['fields']['etat_de_proprietaire']['type']='enum';
$dictionary['Contact']['fields']['etat_de_proprietaire']['massupdate']=true;
$dictionary['Contact']['fields']['etat_de_proprietaire']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['etat_de_proprietaire']['merge_filter']='enabled';
$dictionary['Contact']['fields']['etat_de_proprietaire']['calculated']=false;
$dictionary['Contact']['fields']['etat_de_proprietaire']['required']=true;
$dictionary['Contact']['fields']['etat_de_proprietaire']['len']=100;
$dictionary['Contact']['fields']['etat_de_proprietaire']['audited']=true;
$dictionary['Contact']['fields']['etat_de_proprietaire']['importable']='true';
$dictionary['Contact']['fields']['etat_de_proprietaire']['options']='yes_no_dom';
$dictionary['Contact']['fields']['etat_de_proprietaire']['duplicate_merge_dom_value']='2';
$dictionary['Contact']['fields']['etat_de_proprietaire']['dependency']=false;

 ?>