<?php
 // created: 2018-01-23 15:41:25
$dictionary['Account']['fields']['deleted']['default']=false;
$dictionary['Account']['fields']['deleted']['audited']=false;
$dictionary['Account']['fields']['deleted']['massupdate']=false;
$dictionary['Account']['fields']['deleted']['comments']='Record deletion indicator';
$dictionary['Account']['fields']['deleted']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['deleted']['duplicate_merge_dom_value']=1;
$dictionary['Account']['fields']['deleted']['merge_filter']='disabled';
$dictionary['Account']['fields']['deleted']['reportable']=true;
$dictionary['Account']['fields']['deleted']['unified_search']=false;
$dictionary['Account']['fields']['deleted']['calculated']=false;

 ?>