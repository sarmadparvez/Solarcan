<?php
 // created: 2018-01-25 15:42:20
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_cheque']['name']='numero_de_cheque';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_cheque']['vname']='LBL_NUMERO_DE_CHEQUE';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_cheque']['type']='varchar';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_cheque']['dbType']='varchar';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_cheque']['massupdate']=false;
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_cheque']['duplicate_merge']='enabled';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_cheque']['merge_filter']='enabled';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_cheque']['calculated']=false;
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_cheque']['required']=true;
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_cheque']['audited']=true;
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_cheque']['importable']='true';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_cheque']['duplicate_merge_dom_value']='2';
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_cheque']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['dsm_suivi_de_vente']['fields']['numero_de_cheque']['unified_search']=false;

 ?>