<?php
 // created: 2018-01-25 15:34:42
$dictionary['dsm_suivi_de_vente']['fields']['name']['len']='255';
$dictionary['dsm_suivi_de_vente']['fields']['name']['audited']=false;
$dictionary['dsm_suivi_de_vente']['fields']['name']['massupdate']=false;
$dictionary['dsm_suivi_de_vente']['fields']['name']['unified_search']=false;
$dictionary['dsm_suivi_de_vente']['fields']['name']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.55',
  'searchable' => true,
);
$dictionary['dsm_suivi_de_vente']['fields']['name']['calculated']=false;

 ?>