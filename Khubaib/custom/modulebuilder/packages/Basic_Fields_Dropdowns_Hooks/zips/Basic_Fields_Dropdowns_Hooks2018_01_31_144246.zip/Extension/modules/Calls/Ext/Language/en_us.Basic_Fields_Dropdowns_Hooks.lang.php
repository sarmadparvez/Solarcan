<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['ERR_DELETE_RECORD'] = 'A record number must be specified to delete the Bâtiment.';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Bâtiment';
$mod_strings['LNK_SELECT_ACCOUNT'] = 'Select Bâtiment';
$mod_strings['LNK_NEW_ACCOUNT'] = 'New Bâtiment';
$mod_strings['LBL_RECURRENCE_ID'] = 'Recurrence ID';
$mod_strings['LBL_REPEAT_DAYS'] = 'Repeat days';
$mod_strings['LBL_REPEAT_ORDINAL'] = 'Repeat ordinal';
$mod_strings['LBL_REPEAT_SELECTOR'] = 'Repeat selector';
$mod_strings['LBL_REPEAT_UNIT'] = 'Repeat unit';
$mod_strings['LBL_DISPOSITION'] = 'Disposition';
