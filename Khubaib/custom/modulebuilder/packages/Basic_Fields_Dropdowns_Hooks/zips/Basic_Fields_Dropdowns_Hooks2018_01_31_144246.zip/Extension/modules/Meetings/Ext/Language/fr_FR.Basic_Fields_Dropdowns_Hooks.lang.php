<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_STATUS'] = 'Status:';
$mod_strings['LBL_ANNEE_CONSTRUCTION'] = 'Année construction';
$mod_strings['LBL_NOMBRE_FENETRES_ACHANGER'] = 'Nombre fenetres achanger';
$mod_strings['LBL_NOMBRE_FENETRES_TOTAL'] = 'Nombre fenetres total';
$mod_strings['LBL_NOMBRE_GARAGE_ACHANGER'] = 'Nombre garage achanger';
$mod_strings['LBL_NOMBRE_GARAGE_TOTAL'] = 'Nombre garage total';
$mod_strings['LBL_NOMBRE_PORTES_ACHANGER'] = 'Nombre portes achanger';
$mod_strings['LBL_NOMBRE_PORTES_TOTAL'] = 'Nombre portes total';
$mod_strings['LBL_TYPE'] = 'Meeting Type';
$mod_strings['LBL_ETAT_DE_PROPRIÉTAIRE'] = 'Etat de proprietaire';
$mod_strings['LBL_SOURCE'] = 'Source';
$mod_strings['LBL_OCCUPANT_DEPUIS'] = 'Occupant depuis';
$mod_strings['LBL_PHONE_HOME'] = 'Phone home';
$mod_strings['LBL_PHONE_MOBILE'] = 'Phone mobile';
