<?php
 // created: 2018-01-23 15:44:12
$dictionary['Account']['fields']['duns_num']['len']='15';
$dictionary['Account']['fields']['duns_num']['audited']=false;
$dictionary['Account']['fields']['duns_num']['massupdate']=false;
$dictionary['Account']['fields']['duns_num']['comments']='DUNS number of the account';
$dictionary['Account']['fields']['duns_num']['duplicate_merge']='enabled';
$dictionary['Account']['fields']['duns_num']['duplicate_merge_dom_value']='1';
$dictionary['Account']['fields']['duns_num']['merge_filter']='disabled';
$dictionary['Account']['fields']['duns_num']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.23',
  'searchable' => true,
);
$dictionary['Account']['fields']['duns_num']['calculated']=false;

 ?>