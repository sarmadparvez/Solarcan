<?php
 // created: 2018-01-25 19:25:50
$dictionary['dsm_dnc_historic']['fields']['date_enregistrement']['name']='date_enregistrement';
$dictionary['dsm_dnc_historic']['fields']['date_enregistrement']['vname']='LBL_DATE_ENREGISTREMENT';
$dictionary['dsm_dnc_historic']['fields']['date_enregistrement']['type']='datetime';
$dictionary['dsm_dnc_historic']['fields']['date_enregistrement']['massupdate']=false;
$dictionary['dsm_dnc_historic']['fields']['date_enregistrement']['duplicate_merge']='enabled';
$dictionary['dsm_dnc_historic']['fields']['date_enregistrement']['merge_filter']='enabled';
$dictionary['dsm_dnc_historic']['fields']['date_enregistrement']['calculated']=false;
$dictionary['dsm_dnc_historic']['fields']['date_enregistrement']['required']=false;
$dictionary['dsm_dnc_historic']['fields']['date_enregistrement']['audited']=true;
$dictionary['dsm_dnc_historic']['fields']['date_enregistrement']['importable']='true';
$dictionary['dsm_dnc_historic']['fields']['date_enregistrement']['duplicate_merge_dom_value']='2';
$dictionary['dsm_dnc_historic']['fields']['date_enregistrement']['unified_search']=false;
$dictionary['dsm_dnc_historic']['fields']['date_enregistrement']['enable_range_search']=false;

 ?>