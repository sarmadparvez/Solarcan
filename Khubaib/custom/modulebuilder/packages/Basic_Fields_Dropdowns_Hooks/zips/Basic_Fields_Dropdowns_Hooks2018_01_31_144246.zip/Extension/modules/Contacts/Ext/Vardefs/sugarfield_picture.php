<?php
 // created: 2018-01-25 12:45:06
$dictionary['Contact']['fields']['picture']['len']=255;
$dictionary['Contact']['fields']['picture']['required']=false;
$dictionary['Contact']['fields']['picture']['audited']=false;
$dictionary['Contact']['fields']['picture']['comments']='Avatar';
$dictionary['Contact']['fields']['picture']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['picture']['duplicate_merge_dom_value']=1;
$dictionary['Contact']['fields']['picture']['merge_filter']='disabled';
$dictionary['Contact']['fields']['picture']['reportable']=true;
$dictionary['Contact']['fields']['picture']['calculated']=false;

 ?>