<?php
 // created: 2018-01-24 19:33:37
$dictionary['dsm_dnc']['fields']['source']['name']='source';
$dictionary['dsm_dnc']['fields']['source']['vname']='LBL_SOURCE';
$dictionary['dsm_dnc']['fields']['source']['type']='enum';
$dictionary['dsm_dnc']['fields']['source']['options']='dnc_source_dom';
$dictionary['dsm_dnc']['fields']['source']['massupdate']=false;
$dictionary['dsm_dnc']['fields']['source']['duplicate_merge']='enabled';
$dictionary['dsm_dnc']['fields']['source']['merge_filter']='enabled';
$dictionary['dsm_dnc']['fields']['source']['calculated']=false;
$dictionary['dsm_dnc']['fields']['source']['required']=true;
$dictionary['dsm_dnc']['fields']['source']['audited']=true;
$dictionary['dsm_dnc']['fields']['source']['importable']='true';
$dictionary['dsm_dnc']['fields']['source']['duplicate_merge_dom_value']='2';
$dictionary['dsm_dnc']['fields']['source']['unified_search']=false;
$dictionary['dsm_dnc']['fields']['source']['dependency']=false;

 ?>