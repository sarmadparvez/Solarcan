<?php
 // created: 2018-01-24 12:47:01
$dictionary['Contact']['fields']['email']['len']='100';
$dictionary['Contact']['fields']['email']['required']=true;
$dictionary['Contact']['fields']['email']['audited']=false;
$dictionary['Contact']['fields']['email']['massupdate']=true;
$dictionary['Contact']['fields']['email']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['email']['duplicate_merge_dom_value']='1';
$dictionary['Contact']['fields']['email']['merge_filter']='disabled';
$dictionary['Contact']['fields']['email']['full_text_search']=array (
  'enabled' => true,
  'boost' => '1.95',
  'searchable' => true,
);
$dictionary['Contact']['fields']['email']['calculated']=false;

 ?>