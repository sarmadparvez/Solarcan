<?php
// WARNING: The contents of this file are auto-generated.
$mod_strings['LBL_NAME'] = 'Name';
$mod_strings['LBL_TELEPHONE'] = 'Telephone';
$mod_strings['LBL_SOURCE'] = 'Source';
$mod_strings['LBL_DATE_ENREGISTREMENT'] = 'Date enregistrement';
$mod_strings['LBL_SOURCE_DETAILS_USER_ID'] = 'Source details (related User ID)';
$mod_strings['LBL_SOURCE_DETAILS'] = 'Source details';
$mod_strings['LBL_CONTACT_NAME'] = 'Contact';
$mod_strings['LBL_DSM_DNC_DSM_DNC_HISTORIC_FROM_DSM_DNC_HISTORIC_TITLE'] = 'Do Not Call Historic';
