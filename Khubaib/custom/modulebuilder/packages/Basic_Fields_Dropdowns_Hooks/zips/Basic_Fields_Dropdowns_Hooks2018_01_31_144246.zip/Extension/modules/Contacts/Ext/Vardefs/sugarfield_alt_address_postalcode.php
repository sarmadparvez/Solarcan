<?php
 // created: 2018-01-23 15:34:34
$dictionary['Contact']['fields']['alt_address_postalcode']['audited']=false;
$dictionary['Contact']['fields']['alt_address_postalcode']['massupdate']=false;
$dictionary['Contact']['fields']['alt_address_postalcode']['comments']='Postal code for alternate address';
$dictionary['Contact']['fields']['alt_address_postalcode']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['alt_address_postalcode']['duplicate_merge_dom_value']='1';
$dictionary['Contact']['fields']['alt_address_postalcode']['merge_filter']='disabled';
$dictionary['Contact']['fields']['alt_address_postalcode']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Contact']['fields']['alt_address_postalcode']['calculated']=false;

 ?>