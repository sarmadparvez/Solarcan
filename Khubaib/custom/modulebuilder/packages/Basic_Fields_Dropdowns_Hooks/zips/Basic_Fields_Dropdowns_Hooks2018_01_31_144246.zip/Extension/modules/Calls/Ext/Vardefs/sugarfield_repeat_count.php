<?php
 // created: 2018-01-23 15:38:33
$dictionary['Call']['fields']['repeat_count']['name']='repeat_count';
$dictionary['Call']['fields']['repeat_count']['vname']='LBL_REPEAT_COUNT';
$dictionary['Call']['fields']['repeat_count']['type']='int';
$dictionary['Call']['fields']['repeat_count']['dbType']='int';
$dictionary['Call']['fields']['repeat_count']['massupdate']=false;
$dictionary['Call']['fields']['repeat_count']['duplicate_merge']='enabled';
$dictionary['Call']['fields']['repeat_count']['merge_filter']='enabled';
$dictionary['Call']['fields']['repeat_count']['calculated']=false;
$dictionary['Call']['fields']['repeat_count']['required']=false;
$dictionary['Call']['fields']['repeat_count']['audited']=true;
$dictionary['Call']['fields']['repeat_count']['importable']='true';
$dictionary['Call']['fields']['repeat_count']['duplicate_merge_dom_value']='2';
$dictionary['Call']['fields']['repeat_count']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);

 ?>