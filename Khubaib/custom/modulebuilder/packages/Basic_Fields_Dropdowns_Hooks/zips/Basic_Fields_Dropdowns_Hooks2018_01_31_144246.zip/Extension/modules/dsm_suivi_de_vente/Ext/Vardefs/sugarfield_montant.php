<?php
 // created: 2018-01-25 15:41:59
$dictionary['dsm_suivi_de_vente']['fields']['montant']['name']='montant';
$dictionary['dsm_suivi_de_vente']['fields']['montant']['vname']='LBL_MONTANT';
$dictionary['dsm_suivi_de_vente']['fields']['montant']['type']='varchar';
$dictionary['dsm_suivi_de_vente']['fields']['montant']['dbType']='varchar';
$dictionary['dsm_suivi_de_vente']['fields']['montant']['massupdate']=false;
$dictionary['dsm_suivi_de_vente']['fields']['montant']['duplicate_merge']='enabled';
$dictionary['dsm_suivi_de_vente']['fields']['montant']['merge_filter']='enabled';
$dictionary['dsm_suivi_de_vente']['fields']['montant']['calculated']=false;
$dictionary['dsm_suivi_de_vente']['fields']['montant']['required']=true;
$dictionary['dsm_suivi_de_vente']['fields']['montant']['audited']=true;
$dictionary['dsm_suivi_de_vente']['fields']['montant']['importable']='true';
$dictionary['dsm_suivi_de_vente']['fields']['montant']['duplicate_merge_dom_value']='2';
$dictionary['dsm_suivi_de_vente']['fields']['montant']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['dsm_suivi_de_vente']['fields']['montant']['unified_search']=false;

 ?>