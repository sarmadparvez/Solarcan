<?php
 // created: 2018-01-23 15:34:52
$dictionary['Contact']['fields']['assistant_phone']['len']='100';
$dictionary['Contact']['fields']['assistant_phone']['audited']=false;
$dictionary['Contact']['fields']['assistant_phone']['massupdate']=false;
$dictionary['Contact']['fields']['assistant_phone']['comments']='Phone number of the assistant of the contact';
$dictionary['Contact']['fields']['assistant_phone']['duplicate_merge']='enabled';
$dictionary['Contact']['fields']['assistant_phone']['duplicate_merge_dom_value']='1';
$dictionary['Contact']['fields']['assistant_phone']['merge_filter']='disabled';
$dictionary['Contact']['fields']['assistant_phone']['full_text_search']=array (
  'enabled' => '0',
  'boost' => '1',
  'searchable' => false,
);
$dictionary['Contact']['fields']['assistant_phone']['calculated']=false;

 ?>