<?php
$dictionary['Call']['fields']['revenuelineitems']['workflow'] = true;