<?php
 // created: 2018-01-23 17:03:56
$dictionary['Opportunity']['fields']['statut_apres_vente']['name']='statut_apres_vente';
$dictionary['Opportunity']['fields']['statut_apres_vente']['vname']='LBL_STATUT_APRES_VENTE';
$dictionary['Opportunity']['fields']['statut_apres_vente']['type']='enum';
$dictionary['Opportunity']['fields']['statut_apres_vente']['options']='statut_apres_vente_dom';
$dictionary['Opportunity']['fields']['statut_apres_vente']['massupdate']=false;
$dictionary['Opportunity']['fields']['statut_apres_vente']['duplicate_merge']='enabled';
$dictionary['Opportunity']['fields']['statut_apres_vente']['merge_filter']='enabled';
$dictionary['Opportunity']['fields']['statut_apres_vente']['calculated']=false;
$dictionary['Opportunity']['fields']['statut_apres_vente']['required']=false;
$dictionary['Opportunity']['fields']['statut_apres_vente']['audited']=true;
$dictionary['Opportunity']['fields']['statut_apres_vente']['importable']='true';
$dictionary['Opportunity']['fields']['statut_apres_vente']['duplicate_merge_dom_value']='2';
$dictionary['Opportunity']['fields']['statut_apres_vente']['default']='';
$dictionary['Opportunity']['fields']['statut_apres_vente']['dependency']=false;

 ?>