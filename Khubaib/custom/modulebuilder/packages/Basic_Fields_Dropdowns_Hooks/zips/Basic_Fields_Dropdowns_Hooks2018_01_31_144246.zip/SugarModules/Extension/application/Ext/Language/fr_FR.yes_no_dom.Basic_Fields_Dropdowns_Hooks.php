<?php 
$app_list_strings['yes_no_dom'] = array (
  '' => '',
  'yes' => 'Oui',
  'no' => 'Non',
);