<?php 
$app_list_strings['preferred_language_dom'] = array (
  'francais' => 'Francais',
  'anglais' => 'Anglais',
);