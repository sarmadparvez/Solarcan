<?php 
$app_list_strings['statut_contact_dom'] = array (
  'lead' => 'Lead',
  'prospect_sans_rv' => 'Prospect sans RV',
  'prospect_avec_rv' => 'Prospect AVEC RV',
  'rencontre' => 'Rencontré',
  'client' => 'Client',
);