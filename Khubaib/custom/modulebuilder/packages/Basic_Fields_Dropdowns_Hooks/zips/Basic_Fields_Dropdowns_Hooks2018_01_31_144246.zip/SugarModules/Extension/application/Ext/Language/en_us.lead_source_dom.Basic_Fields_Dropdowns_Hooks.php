<?php 
$app_list_strings['lead_source_dom'] = array (
  'site_web' => 'Site Web',
  'hit' => 'HIT',
  'reno_depot' => 'Reno Depot',
  'autre' => 'Autre',
);