<?php 
$app_list_strings['meeting_status_dom'] = array (
  'planifie' => 'Planifié',
  'confirme_au_client' => 'Confirmé au client',
  'complete' => 'Complété',
  'annule' => 'Annulé',
);