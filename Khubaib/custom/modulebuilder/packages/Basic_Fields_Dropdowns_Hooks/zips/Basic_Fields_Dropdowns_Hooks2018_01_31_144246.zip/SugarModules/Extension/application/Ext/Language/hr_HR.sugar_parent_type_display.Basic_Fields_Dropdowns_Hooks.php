<?php 
$app_list_strings['parent_type_display'] = array (
  'Accounts' => 'Račun',
  'Contacts' => 'Kontakt',
  'Tasks' => 'Zadatak',
  'Opportunities' => 'Prilika',
  'Products' => 'Prodana stavka',
  'Quotes' => 'Ponuda',
  'Bugs' => 'Pogreške',
  'Cases' => 'Slučaj',
  'Leads' => 'Pot. kl.',
  'Project' => 'Projekt',
  'ProjectTask' => 'Projektni zadatak',
  'Prospects' => 'Meta',
  'KBContents' => 'Baza znanja',
  'RevenueLineItems' => 'Stavke prihoda',
);