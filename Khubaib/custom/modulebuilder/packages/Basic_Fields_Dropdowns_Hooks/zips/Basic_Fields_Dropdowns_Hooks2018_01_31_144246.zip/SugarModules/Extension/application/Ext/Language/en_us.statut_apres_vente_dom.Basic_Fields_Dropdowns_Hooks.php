<?php 
$app_list_strings['statut_apres_vente_dom'] = array (
  '' => '',
  'vente confirmee' => 'Vente confirmée',
  'en_evaluation_financiere' => 'En évaluation financière',
  'refus_bancaire' => 'Refus bancaire',
  'annule_par_le_client' => 'Annulé par le client',
  'en_production' => 'En production',
);