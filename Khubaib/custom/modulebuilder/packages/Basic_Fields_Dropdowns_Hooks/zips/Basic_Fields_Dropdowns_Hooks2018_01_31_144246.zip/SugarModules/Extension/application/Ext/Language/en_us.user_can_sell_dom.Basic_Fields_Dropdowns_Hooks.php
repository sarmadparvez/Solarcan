<?php 
$app_list_strings['user_can_sell_dom'] = array (
  '' => '',
  'category_1' => 'Category 1',
  'category_2' => 'Category 2',
  'category_3' => 'Category 3',
);