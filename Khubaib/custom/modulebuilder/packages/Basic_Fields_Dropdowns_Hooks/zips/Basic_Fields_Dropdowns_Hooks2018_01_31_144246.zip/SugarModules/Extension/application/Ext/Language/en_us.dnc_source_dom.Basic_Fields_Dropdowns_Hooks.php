<?php 
$app_list_strings['dnc_source_dom'] = array (
  '' => '',
  'agent' => 'Agent',
  'Import' => 'Import',
);