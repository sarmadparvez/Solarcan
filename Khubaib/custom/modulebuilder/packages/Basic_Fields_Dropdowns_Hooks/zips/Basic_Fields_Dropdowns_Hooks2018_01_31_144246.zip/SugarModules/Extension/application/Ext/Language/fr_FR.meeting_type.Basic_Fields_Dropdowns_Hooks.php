<?php 
$app_list_strings['meeting_type'] = array (
  '1ere_rencontre' => '1ere Rencontre',
  '2e_rencontre' => '2e rencontre',
  'autre' => 'Autre',
);