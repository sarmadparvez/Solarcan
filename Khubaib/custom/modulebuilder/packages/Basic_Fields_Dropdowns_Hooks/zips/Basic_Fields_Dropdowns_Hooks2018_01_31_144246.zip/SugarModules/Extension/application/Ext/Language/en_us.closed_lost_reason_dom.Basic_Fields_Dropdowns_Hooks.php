<?php 
$app_list_strings['closed_lost_reason_dom'] = array (
  'prix' => 'Prix',
  'produit' => 'Produit',
  'competiteur' => 'Compétiteur',
  'autres' => 'Autres',
);