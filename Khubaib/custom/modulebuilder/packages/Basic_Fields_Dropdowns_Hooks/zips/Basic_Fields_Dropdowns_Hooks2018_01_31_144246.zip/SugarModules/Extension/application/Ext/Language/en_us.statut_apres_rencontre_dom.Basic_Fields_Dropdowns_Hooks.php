<?php 
$app_list_strings['statut_apres_rencontre_dom'] = array (
  'vente' => 'Vente',
  'soumission' => 'Soumission',
  'annulee' => 'Annulée',
  'no_show' => 'No-Show',
  'non_rencontre' => 'Non-Rencontré',
);