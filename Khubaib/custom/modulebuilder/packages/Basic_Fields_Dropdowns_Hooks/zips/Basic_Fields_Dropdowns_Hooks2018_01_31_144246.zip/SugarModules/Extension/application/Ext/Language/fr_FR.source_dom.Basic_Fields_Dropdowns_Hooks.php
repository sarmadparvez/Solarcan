<?php 
$app_list_strings['source_dom'] = array (
  '' => '',
  'interne' => 'Interne',
  'partenaire' => 'Partenaire',
);