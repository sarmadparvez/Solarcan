<?php 
$app_list_strings['source_details_dom'] = array (
  '' => '',
  'hit' => 'HIT',
  'reno_depot' => 'Reno Depot',
);