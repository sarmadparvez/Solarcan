<?php
// created: 2018-01-31 12:37:05
$dictionary["rt_postal_codes"]["fields"]["rt_postal_codes_users"] = array (
  'name' => 'rt_postal_codes_users',
  'type' => 'link',
  'relationship' => 'rt_postal_codes_users',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'vname' => 'LBL_RT_POSTAL_CODES_USERS_FROM_USERS_TITLE',
  'id_name' => 'rt_postal_codes_usersusers_idb',
);
