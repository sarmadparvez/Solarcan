<?php
// created: 2018-01-31 12:37:05
$viewdefs['rt_postal_codes']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_RT_POSTAL_CODES_USERS_FROM_USERS_TITLE',
  'context' => 
  array (
    'link' => 'rt_postal_codes_users',
  ),
);