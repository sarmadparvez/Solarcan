<?php
/*
 * Your installation or use of this SugarCRM file is subject to the applicable
 * terms available at
 * http://support.sugarcrm.com/Resources/Master_Subscription_Agreements/.
 * If you do not agree to all of the applicable terms or do not have the
 * authority to bind the entity as an authorized representative, then do not
 * install or use this SugarCRM file.
 *
 * Copyright (C) SugarCRM Inc. All rights reserved.
 */
$mod_strings = array (
  'LBL_TEAM' => 'Teams',
  'LBL_TEAMS' => 'Teams',
  'LBL_TEAM_ID' => 'Team Id',
  'LBL_ASSIGNED_TO_ID' => 'Assigned User Id',
  'LBL_ASSIGNED_TO_NAME' => 'Assigned to',
  'LBL_TAGS_LINK' => 'Tags',
  'LBL_TAGS' => 'Tags',
  'LBL_ID' => 'ID',
  'LBL_DATE_ENTERED' => 'Date Created',
  'LBL_DATE_MODIFIED' => 'Date Modified',
  'LBL_MODIFIED' => 'Modified By',
  'LBL_MODIFIED_ID' => 'Modified By Id',
  'LBL_MODIFIED_NAME' => 'Modified By Name',
  'LBL_CREATED' => 'Created By',
  'LBL_CREATED_ID' => 'Created By Id',
  'LBL_DOC_OWNER' => 'Document Owner',
  'LBL_USER_FAVORITES' => 'Users Who Favorite',
  'LBL_DESCRIPTION' => 'Description',
  'LBL_DELETED' => 'Deleted',
  'LBL_NAME' => 'Classification',
  'LBL_CREATED_USER' => 'Created by User',
  'LBL_MODIFIED_USER' => 'Modified by User',
  'LBL_LIST_NAME' => 'Name',
  'LBL_EDIT_BUTTON' => 'Edit',
  'LBL_REMOVE' => 'Remove',
  'LBL_EXPORT_MODIFIED_BY_NAME' => 'Modified By Name',
  'LBL_LIST_FORM_TITLE' => 'Classification List',
  'LBL_MODULE_NAME' => 'Classification',
  'LBL_MODULE_TITLE' => 'Classification',
  'LBL_MODULE_NAME_SINGULAR' => 'Classification',
  'LBL_HOMEPAGE_TITLE' => 'My Classification',
  'LNK_NEW_RECORD' => 'Create Classification',
  'LNK_LIST' => 'View Classification',
  'LNK_IMPORT_RT_CLASSIFICATION' => 'Import Classification',
  'LBL_SEARCH_FORM_TITLE' => 'Search Classification',
  'LBL_HISTORY_SUBPANEL_TITLE' => 'View History',
  'LBL_ACTIVITIES_SUBPANEL_TITLE' => 'Activity Stream',
  'LBL_RT_CLASSIFICATION_SUBPANEL_TITLE' => 'Classification',
  'LBL_NEW_FORM_TITLE' => 'New Classification',
  'LNK_IMPORT_VCARD' => 'Import Classification vCard',
  'LBL_IMPORT' => 'Import Classification',
  'LBL_IMPORT_VCARDTEXT' => 'Automatically create a new Classification record by importing a vCard from your file system.',
  'LBL_EFFICIENCY' => 'Efficiency',
  'LBL_MIN_APPOINTMENT_PER_WEEK' => 'Min no of appointments per week',
  'LBL_MAX_APPOINTMENT_PER_WEEK' => 'Max no of appointments per week',
  'LBL_APPOINTMENT_PER_DAY' => 'No of appointments per day',
  'LBL_SURPLUS_APPOINTMENT_COUNT' => 'No of appointments when surplus',
);