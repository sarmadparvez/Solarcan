<?php
// created: 2018-01-31 11:47:16
$viewdefs['rt_Classification']['mobile']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_RT_CLASSIFICATION_USERS_FROM_USERS_TITLE',
  'context' => 
  array (
    'link' => 'rt_classification_users',
  ),
);