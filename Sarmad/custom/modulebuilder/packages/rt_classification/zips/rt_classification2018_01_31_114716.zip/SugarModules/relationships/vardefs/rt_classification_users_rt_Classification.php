<?php
// created: 2018-01-31 11:47:16
$dictionary["rt_Classification"]["fields"]["rt_classification_users"] = array (
  'name' => 'rt_classification_users',
  'type' => 'link',
  'relationship' => 'rt_classification_users',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'vname' => 'LBL_RT_CLASSIFICATION_USERS_FROM_RT_CLASSIFICATION_TITLE',
  'id_name' => 'rt_classification_usersrt_classification_ida',
  'link-type' => 'many',
  'side' => 'left',
);
