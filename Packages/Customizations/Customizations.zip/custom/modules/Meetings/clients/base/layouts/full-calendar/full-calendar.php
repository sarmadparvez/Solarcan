<?php

$viewdefs['Meetings']['base']['layout']['full-calendar'] = array(
    'type' => 'simple',
    //'span' => 12,
    'components' =>
    array(
        array(
            'view' => 'full-calendar',
        ),
    ),
);
