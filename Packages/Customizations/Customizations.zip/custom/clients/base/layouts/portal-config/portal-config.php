<?php
$viewdefs['base']['layout']['portal-config'] = array(
    'type' => 'simple',
    'components' => array(
        array(
            'view' => 'portal-config',
        ),
    ),
);
