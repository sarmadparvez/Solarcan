<?php

$platforms[] = 'portal-integration';

