<?php

$platforms[] = 'voxco-integration';
