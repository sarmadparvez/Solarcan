<?php

//create the links label
$app_strings['LNK_SALES_REP_SCHEDULE'] = 'Sales Rep Schedule';
