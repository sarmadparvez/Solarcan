<?php
$mod_strings['LBL_MEETINGASSIGNATIONWORKFLOW'] = 'Meeting Assignation Workflow';
