<?php
// created: 2018-05-03 10:49:25
$viewdefs['tm_telemarketers']['base']['layout']['subpanels']['components'][] = array (
  'layout' => 'subpanel',
  'label' => 'LBL_MEETINGS',
  'context' => 
  array (
    'link' => 'telemarketers_meetings',
  ),
);