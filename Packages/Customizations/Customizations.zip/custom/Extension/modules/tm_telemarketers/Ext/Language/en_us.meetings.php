<?php

$mod_strings['LBL_MEETINGS'] = 'Meetings';
