<?php

$viewdefs['Meetings']['base']['menu']['header'][] = array(
    'route'=>'#Meetings/layout/full-calendar',
    'label' =>'LNK_SALES_REP_SCHEDULE',
    'acl_module'=>'Meetings',
    'icon' => 'icon-user',
);
