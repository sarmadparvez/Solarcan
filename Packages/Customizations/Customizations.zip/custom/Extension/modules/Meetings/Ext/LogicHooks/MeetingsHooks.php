<?php

    $hook_array['before_save'][] = array(
        1,
        '',
        'custom/modules/Meetings/MeetingsHooksImpl.php',
        'MeetingsHooksImpl',
        'beforeSave'
    );