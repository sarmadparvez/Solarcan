
<?php
$dictionary['Meeting']['acls']['SugarACLFieldOverride'] = true;