<?php

$mod_strings['LBL_TELEMARKETER'] = 'Telemarketer';
$mod_strings['LBL_TELEMARKETER_ID'] = 'Telemarketer ID';
