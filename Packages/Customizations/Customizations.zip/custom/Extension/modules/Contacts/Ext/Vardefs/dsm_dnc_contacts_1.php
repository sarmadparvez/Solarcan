<?php
// created: 2018-05-16 09:52:19
$dictionary["Contact"]["fields"]["dsm_dnc_contacts_1"] = array (
  'name' => 'dsm_dnc_contacts_1',
  'type' => 'link',
  'relationship' => 'dsm_dnc_contacts_1',
  'source' => 'non-db',
  'module' => 'dsm_dnc',
  'bean_name' => 'dsm_dnc',
  'vname' => 'LBL_DSM_DNC_CONTACTS_1_FROM_DSM_DNC_TITLE',
  'id_name' => 'dsm_dnc_contacts_1dsm_dnc_ida',
);
$dictionary["Contact"]["fields"]["dsm_dnc_contacts_1_name"] = array (
  'name' => 'dsm_dnc_contacts_1_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_DSM_DNC_CONTACTS_1_FROM_DSM_DNC_TITLE',
  'save' => true,
  'id_name' => 'dsm_dnc_contacts_1dsm_dnc_ida',
  'link' => 'dsm_dnc_contacts_1',
  'table' => 'dsm_dnc',
  'module' => 'dsm_dnc',
  'rname' => 'name',
);
$dictionary["Contact"]["fields"]["dsm_dnc_contacts_1dsm_dnc_ida"] = array (
  'name' => 'dsm_dnc_contacts_1dsm_dnc_ida',
  'type' => 'id',
  'source' => 'non-db',
  'vname' => 'LBL_DSM_DNC_CONTACTS_1_FROM_DSM_DNC_TITLE_ID',
  'id_name' => 'dsm_dnc_contacts_1dsm_dnc_ida',
  'link' => 'dsm_dnc_contacts_1',
  'table' => 'dsm_dnc',
  'module' => 'dsm_dnc',
  'rname' => 'id',
  'reportable' => false,
  'side' => 'left',
  'massupdate' => false,
  'duplicate_merge' => 'disabled',
  'hideacl' => true,
);

