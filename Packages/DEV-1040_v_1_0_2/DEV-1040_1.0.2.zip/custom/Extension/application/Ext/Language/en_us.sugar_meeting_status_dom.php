<?php
 // created: 2018-09-04 15:11:51

$app_list_strings['meeting_status_dom']=array (
  'disponible' => 'Disponible',
  //'en_attente_dassignation' => 'En attente d\'assignation',
  'assigne' => 'ASSIGNÉ',
  'confirme_au_client' => 'Confirmé au client',
  'complete' => 'Complété',
  'annule' => 'Annulé',
  'changer_de_representant' => 'Modification',
);