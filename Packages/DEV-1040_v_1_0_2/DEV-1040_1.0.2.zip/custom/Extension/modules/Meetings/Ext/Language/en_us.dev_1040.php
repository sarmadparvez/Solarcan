<?php

$mod_strings['LBL_WAITING_FOR_ASSIGNATION'] = "En attente d'assignation";
